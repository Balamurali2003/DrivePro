<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($admin_title ?? 'Admin') ?> — SMK Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg:            #F4F4F5;
      --sidebar:       #111111;
      --sidebar-bdr:   rgba(255,255,255,.07);
      --sidebar-muted: rgba(255,255,255,.45);
      --sidebar-hover: rgba(255,255,255,.06);
      --sidebar-act:   rgba(255,255,255,.1);
      --card:          #ffffff;
      --bdr:           #E4E4E7;
      --bdr-focus:     #F59E0B;
      --text:          #18181B;
      --muted:         #71717A;
      --xs-muted:      #A1A1AA;
      --accent:        #F59E0B;
      --accent-hover:  #D97706;
      --accent-text:   #111111;
      --r:             8px;
      --r-lg:          12px;
      --shadow-sm:     0 1px 2px rgba(0,0,0,.05);
      --shadow:        0 1px 4px rgba(0,0,0,.07), 0 1px 2px rgba(0,0,0,.04);
      --shadow-md:     0 4px 12px rgba(0,0,0,.08), 0 2px 4px rgba(0,0,0,.04);
    }

    html, body { height: 100%; }

    body {
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      font-size: 14px;
      line-height: 1.5;
      background: var(--bg);
      color: var(--text);
      -webkit-font-smoothing: antialiased;
    }

    /* ── Layout ──────────────────────────────────────────────────────── */
    .adm-wrap    { display: flex; min-height: 100vh; }
    .adm-sidebar { width: 220px; background: var(--sidebar); display: flex; flex-direction: column; flex-shrink: 0; }
    .adm-main    { flex: 1; display: flex; flex-direction: column; min-width: 0; overflow: hidden; }

    /* ── Sidebar ─────────────────────────────────────────────────────── */
    .adm-brand {
      padding: 20px 16px 18px;
      border-bottom: 1px solid var(--sidebar-bdr);
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .adm-brand-icon {
      width: 32px; height: 32px;
      background: var(--accent);
      border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .adm-brand-icon svg { display: block; }
    .adm-brand-name  { color: #fff; font-size: 14px; font-weight: 600; letter-spacing: -.01em; }
    .adm-brand-sub   { color: var(--sidebar-muted); font-size: 11px; margin-top: 1px; }

    .adm-nav       { flex: 1; padding: 10px 8px; }
    .adm-nav-label { color: var(--sidebar-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; padding: 12px 8px 6px; }
    .adm-nav-item  {
      display: flex; align-items: center; gap: 9px;
      padding: 8px 10px;
      border-radius: 7px;
      color: var(--sidebar-muted);
      text-decoration: none;
      font-size: 13px;
      font-weight: 500;
      transition: background .15s, color .15s;
      margin-bottom: 1px;
    }
    .adm-nav-item svg { flex-shrink: 0; opacity: .7; transition: opacity .15s; }
    .adm-nav-item:hover { background: var(--sidebar-hover); color: rgba(255,255,255,.85); }
    .adm-nav-item:hover svg { opacity: 1; }
    .adm-nav-item.active { background: var(--sidebar-act); color: #fff; }
    .adm-nav-item.active svg { opacity: 1; }

    .adm-sidebar-footer {
      padding: 10px 8px 16px;
      border-top: 1px solid var(--sidebar-bdr);
    }

    /* ── Topbar ──────────────────────────────────────────────────────── */
    .adm-topbar {
      background: var(--card);
      border-bottom: 1px solid var(--bdr);
      padding: 0 28px;
      height: 56px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-shrink: 0;
    }
    .adm-topbar-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--text);
      letter-spacing: -.01em;
    }

    /* ── Content ─────────────────────────────────────────────────────── */
    .adm-content { flex: 1; padding: 28px; overflow-y: auto; }

    /* ── Buttons ─────────────────────────────────────────────────────── */
    .btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 8px 16px;
      border-radius: var(--r);
      font-size: 13px; font-weight: 600;
      text-decoration: none;
      cursor: pointer;
      border: none;
      transition: background .15s, box-shadow .15s, opacity .15s;
      white-space: nowrap;
    }
    .btn:active { opacity: .85; }
    .btn-primary { background: var(--accent); color: var(--accent-text); }
    .btn-primary:hover { background: var(--accent-hover); }
    .btn-ghost {
      background: transparent;
      color: var(--muted);
      border: 1px solid var(--bdr);
    }
    .btn-ghost:hover { background: var(--bg); color: var(--text); }
    .btn-danger-ghost {
      background: transparent;
      color: #DC2626;
      border: none;
      font-size: 13px; font-weight: 500;
      cursor: pointer;
      padding: 0;
    }
    .btn-danger-ghost:hover { text-decoration: underline; }
    .btn-link {
      background: transparent; border: none;
      color: var(--accent-hover); font-size: 13px; font-weight: 500;
      cursor: pointer; padding: 0; text-decoration: none;
    }
    .btn-link:hover { text-decoration: underline; }
    .btn-sm { padding: 5px 12px; font-size: 12px; }

    /* ── Alerts ──────────────────────────────────────────────────────── */
    .alert {
      display: flex; align-items: flex-start; gap: 10px;
      padding: 12px 14px;
      border-radius: var(--r-lg);
      font-size: 13px;
      font-weight: 500;
      margin-bottom: 20px;
      border: 1px solid;
    }
    .alert svg { flex-shrink: 0; margin-top: 1px; }
    .alert-success { background: #F0FDF4; border-color: #BBF7D0; color: #15803D; }
    .alert-error   { background: #FEF2F2; border-color: #FECACA; color: #B91C1C; }
    .alert-body    { display: flex; flex-direction: column; gap: 2px; }
    .alert-title   { font-weight: 600; }

    /* ── Card ────────────────────────────────────────────────────────── */
    .card {
      background: var(--card);
      border: 1px solid var(--bdr);
      border-radius: var(--r-lg);
      box-shadow: var(--shadow);
    }

    /* ── Table ───────────────────────────────────────────────────────── */
    .adm-table { width: 100%; border-collapse: collapse; }
    .adm-table thead th {
      background: #FAFAFA;
      padding: 10px 18px;
      text-align: left;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: .06em;
      color: var(--muted);
      border-bottom: 1px solid var(--bdr);
    }
    .adm-table thead th:first-child { border-radius: var(--r-lg) 0 0 0; }
    .adm-table thead th:last-child  { border-radius: 0 var(--r-lg) 0 0; }
    .adm-table tbody tr {
      border-bottom: 1px solid var(--bdr);
      transition: background .1s;
    }
    .adm-table tbody tr:last-child { border-bottom: none; }
    .adm-table tbody tr:hover { background: #FAFAFA; }
    .adm-table td { padding: 14px 18px; vertical-align: middle; }
    .adm-table .col-title  { font-weight: 500; color: var(--text); max-width: 280px; }
    .adm-table .col-slug   { font-family: 'SFMono-Regular', 'Consolas', monospace; font-size: 11.5px; color: var(--muted); max-width: 180px; }
    .adm-table .col-date   { font-size: 12.5px; color: var(--muted); white-space: nowrap; }
    .adm-table .col-actions { text-align: right; white-space: nowrap; }
    .truncate-cell { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: block; }

    /* ── Badges ──────────────────────────────────────────────────────── */
    .badge {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 3px 9px;
      border-radius: 99px;
      font-size: 11.5px;
      font-weight: 600;
      letter-spacing: .01em;
    }
    .badge-dot { width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0; }
    .badge-published { background: #F0FDF4; color: #15803D; }
    .badge-published .badge-dot { background: #22C55E; }
    .badge-draft     { background: #FEFCE8; color: #92400E; }
    .badge-draft .badge-dot     { background: #F59E0B; }

    /* ── Form ────────────────────────────────────────────────────────── */
    .form-group  { display: flex; flex-direction: column; gap: 6px; }
    .form-label  { font-size: 13px; font-weight: 500; color: var(--text); }
    .form-hint   { font-size: 11.5px; color: var(--xs-muted); }
    .form-req    { color: #EF4444; margin-left: 2px; }

    .form-input,
    .form-textarea {
      width: 100%;
      background: var(--card);
      border: 1px solid #D4D4D8;
      border-radius: var(--r);
      padding: 9px 13px;
      font-family: inherit;
      font-size: 14px;
      color: var(--text);
      outline: none;
      transition: border-color .15s, box-shadow .15s;
      -webkit-appearance: none;
    }
    .form-input::placeholder,
    .form-textarea::placeholder { color: #A1A1AA; }
    .form-input:focus,
    .form-textarea:focus {
      border-color: var(--bdr-focus);
      box-shadow: 0 0 0 3px rgba(245,158,11,.14);
    }
    .form-input-mono { font-family: 'SFMono-Regular', 'Consolas', monospace; font-size: 13px; }
    .form-textarea   { resize: vertical; line-height: 1.6; }
    .form-textarea-code { font-family: 'SFMono-Regular', 'Consolas', monospace; font-size: 12.5px; }

    .form-toggle-row {
      display: flex; align-items: center; gap: 10px;
      padding: 12px 14px;
      background: var(--bg);
      border: 1px solid var(--bdr);
      border-radius: var(--r);
      cursor: pointer;
      user-select: none;
    }
    .form-toggle-row input[type="checkbox"] {
      width: 16px; height: 16px; accent-color: var(--accent); cursor: pointer; flex-shrink: 0;
    }
    .form-toggle-label { font-size: 13px; font-weight: 500; color: var(--text); }
    .form-toggle-desc  { font-size: 12px; color: var(--muted); }

    .form-actions { display: flex; gap: 10px; padding-top: 6px; }

    /* ── Empty state ─────────────────────────────────────────────────── */
    .empty-state {
      padding: 64px 32px;
      text-align: center;
      color: var(--muted);
    }
    .empty-state svg { margin: 0 auto 14px; opacity: .35; display: block; }
    .empty-state h3  { font-size: 15px; font-weight: 600; color: var(--text); margin-bottom: 6px; }
    .empty-state p   { font-size: 13px; }

    /* ── Divider ─────────────────────────────────────────────────────── */
    .adm-divider { height: 1px; background: var(--sidebar-bdr); margin: 4px 0; }

    .pagination { display:flex; align-items:center; gap:4px; flex-wrap:wrap; }
    .pg-btn {
      display:inline-flex; align-items:center; justify-content:center;
      min-width:34px; height:34px; padding:0 8px;
      border-radius:var(--r); font-size:13px; font-weight:500;
      color:var(--text); background:var(--card); border:1px solid var(--bdr);
      text-decoration:none; transition:background .12s,border-color .12s;
    }
    .pg-btn:hover { background:var(--bg); border-color:#D4D4D8; }
    .pg-current { background:var(--accent); border-color:var(--accent); color:var(--accent-text); font-weight:600; }
    .pg-current:hover { background:var(--accent-hover); border-color:var(--accent-hover); }
    .pg-disabled { opacity:.4; cursor:default; pointer-events:none; }
    .pg-ellipsis { display:inline-flex; align-items:center; padding:0 4px; color:var(--muted); font-size:13px; }
  </style>
</head>
<body>
<div class="adm-wrap">

  <!-- Sidebar -->
  <aside class="adm-sidebar">
    <div class="adm-brand">
      <div class="adm-brand-icon">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 12L8 4l5 8H3z" fill="#111"/></svg>
      </div>
      <div>
        <div class="adm-brand-name">SMK Admin</div>
        <div class="adm-brand-sub">Driving School</div>
      </div>
    </div>

    <nav class="adm-nav">
      <div class="adm-nav-label">Content</div>
      <?php
      $current = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
      $is_edit = str_starts_with($current, '/admin/posts/edit');
      $admin_nav = [
          [
            'href'   => '/admin/posts',
            'label'  => 'All Posts',
            'active' => $current === '/admin/posts',
            'icon'   => '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
          ],
          [
            'href'   => '/admin/posts/create',
            'label'  => 'New Post',
            'active' => $current === '/admin/posts/create',
            'icon'   => '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
          ],
      ];
      if ($is_edit) {
          $admin_nav[] = [
              'href'   => $current,
              'label'  => 'Editing Post',
              'active' => true,
              'icon'   => '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
          ];
      }
      foreach ($admin_nav as $item):
          $cls = $item['active'] ? 'adm-nav-item active' : 'adm-nav-item';
      ?>
      <a href="<?= $item['href'] ?>" class="<?= $cls ?>">
        <?= $item['icon'] ?>
        <?= htmlspecialchars($item['label']) ?>
      </a>
      <?php endforeach; ?>

      <div class="adm-divider" style="margin:8px 0"></div>
      <div class="adm-nav-label">Leads</div>
      <?php
      $unread_count = count_enquiries(true);
      $enq_cls = ($current === '/admin/enquiries') ? 'adm-nav-item active' : 'adm-nav-item';
      ?>
      <a href="/admin/enquiries" class="<?= $enq_cls ?>">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
        Enquiries
        <?php if ($unread_count > 0): ?>
        <span style="margin-left:auto;background:#EF4444;color:#fff;font-size:10px;font-weight:700;min-width:18px;height:18px;border-radius:99px;display:inline-flex;align-items:center;justify-content:center;padding:0 4px">
          <?= $unread_count ?>
        </span>
        <?php endif; ?>
      </a>
    </nav>

    <div class="adm-sidebar-footer">
      <a href="/" target="_blank" class="adm-nav-item">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        View site
      </a>
      <a href="/admin/logout" class="adm-nav-item">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        Log out
      </a>
    </div>
  </aside>

  <!-- Main -->
  <main class="adm-main">
    <!-- Topbar -->
    <header class="adm-topbar">
      <h1 class="adm-topbar-title"><?= htmlspecialchars($admin_title ?? 'Dashboard') ?></h1>
      <?php if (!empty($admin_action)): ?>
      <a href="<?= htmlspecialchars($admin_action['href']) ?>" class="btn btn-primary btn-sm">
        <?= htmlspecialchars($admin_action['label']) ?>
      </a>
      <?php endif; ?>
    </header>

    <!-- Content -->
    <div class="adm-content">
      <?php if (!empty($admin_flash)): ?>
      <?php $is_err = $admin_flash['type'] === 'error'; ?>
      <div class="alert <?= $is_err ? 'alert-error' : 'alert-success' ?>">
        <?php if ($is_err): ?>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?php else: ?>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        <?php endif; ?>
        <span><?= htmlspecialchars($admin_flash['message']) ?></span>
      </div>
      <?php endif; ?>

      <?= $admin_content ?? '' ?>
    </div>
  </main>

</div>
</body>
</html>
