<?php
$perks = [
    ['icon' => 'heart',  't' => 'Female-friendly', 'd' => 'Comfortable, judgement-free space.'],
    ['icon' => 'shield', 't' => 'Confidence-first', 'd' => 'We focus on calm, fearless driving.'],
    ['icon' => 'clock',  't' => 'Flexible timing',  'd' => 'Pick a slot that suits your day.'],
    ['icon' => 'users',  't' => 'Family welcome',   'd' => 'Bring a parent or friend along.'],
];
?>
<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-7xl px-4">
    <div class="rounded-[2.5rem] overflow-hidden bg-gradient-to-br from-yellow/15 via-surface to-background border border-yellow/30 shadow-card">
      <div class="grid lg:grid-cols-2 items-stretch">

        <div class="relative min-h-[400px] order-2 lg:order-1">
          <img src="/assets/images/woman-driver.jpg" alt="Confident woman learning to drive"
               loading="lazy" width="1024" height="1280"
               class="absolute inset-0 h-full w-full object-cover" />
        </div>

        <div class="p-8 md:p-14 order-1 lg:order-2">
          <span class="inline-flex items-center gap-2 rounded-full bg-ink text-yellow px-3 py-1 text-xs font-semibold uppercase tracking-widest">
            <?= icon('heart', 'size-3') ?> Ladies Special
          </span>
          <h2 class="mt-5 text-4xl md:text-5xl font-display font-bold text-ink leading-tight">
            Women safe driving program
          </h2>
          <p class="mt-4 text-muted-foreground text-lg">
            A dedicated, supportive program designed for women learners — from absolute beginners to those rebuilding confidence after a long break.
          </p>

          <div class="mt-8 grid sm:grid-cols-2 gap-4">
            <?php foreach ($perks as $p): ?>
              <div class="reveal flex gap-3 rounded-2xl bg-card border border-border p-4">
                <div class="h-10 w-10 rounded-xl bg-gradient-yellow flex items-center justify-center shrink-0">
                  <?= icon($p['icon'], 'size-4 text-ink') ?>
                </div>
                <div>
                  <div class="font-display font-semibold text-ink"><?= htmlspecialchars($p['t']) ?></div>
                  <div class="text-xs text-muted-foreground mt-0.5"><?= htmlspecialchars($p['d']) ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <a href="/book-demo" class="inline-block mt-8">
            <button class="inline-flex items-center gap-2 rounded-full px-6 py-3 text-base font-semibold bg-ink text-white hover:opacity-90 transition-opacity">
              Book Ladies Demo Class
            </button>
          </a>
        </div>

      </div>
    </div>
  </div>
</section>
