<?php
$points = [
    'Real Tirunelveli road experience — not parking lots',
    'Patient, certified trainers who explain in Tamil & English',
    'Defensive & safe driving education first, license second',
    'Confidence building for first-time and nervous drivers',
    'Personalized one-to-one training pace',
];
?>
<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-7xl px-4 grid gap-12 lg:grid-cols-2 items-center">

    <div class="reveal relative">
      <div class="relative rounded-3xl overflow-hidden shadow-glow">
        <img src="/assets/images/lesson.jpg" alt="Driving lesson in progress"
             loading="lazy" width="1280" height="896"
             class="w-full aspect-[4/3] object-cover" />
        <div class="absolute inset-0 ring-1 ring-inset ring-white/10"></div>
      </div>
      <div class="absolute -bottom-6 -left-6 hidden md:block bg-ink text-white rounded-2xl p-5 shadow-glow">
        <div class="text-4xl font-display font-bold text-yellow">15+</div>
        <div class="text-xs uppercase tracking-widest mt-1">Years of training</div>
      </div>
      <div class="absolute -top-6 -right-6 hidden md:block bg-gradient-yellow text-ink rounded-2xl p-5 shadow-glow">
        <div class="text-4xl font-display font-bold">500+</div>
        <div class="text-xs uppercase tracking-widest mt-1">Happy learners</div>
      </div>
    </div>

    <div class="reveal">
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">About us</span>
      <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold text-ink leading-tight">
        Why Tirunelveli learners <span class="text-gradient-yellow">choose us</span>
      </h2>
      <p class="mt-5 text-muted-foreground text-lg">
        We don't just hand out licenses — we build drivers who are calm, confident, and ready for any Indian road. Every class is hands-on, supportive, and focused on real-world safety.
      </p>
      <ul class="mt-8 space-y-4">
        <?php foreach ($points as $p): ?>
          <li class="flex gap-3">
            <?= icon('check-circle', 'size-5 text-yellow-deep shrink-0 mt-0.5') ?>
            <span class="text-ink"><?= htmlspecialchars($p) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>

  </div>
</section>
