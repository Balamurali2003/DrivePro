<?php
$items = [
    ['src' => 'hero-car.jpg',        'alt' => 'Premium training car',              'span' => 'md:col-span-2 md:row-span-2'],
    ['src' => 'lesson.jpg',          'alt' => 'Driving lesson in progress',        'span' => ''],
    ['src' => 'license-success.jpg', 'alt' => 'Student with new driving license',  'span' => ''],
    ['src' => 'woman-driver.jpg',    'alt' => 'Woman driving practice',            'span' => ''],
    ['src' => 'car-lboard.jpg',      'alt' => 'Driving school car with L board',   'span' => 'md:col-span-2'],
];
$compact = $compact ?? false;
?>
<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-7xl px-4">
    <?php if (!$compact): ?>
      <div class="text-center max-w-2xl mx-auto mb-14">
        <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">Gallery</span>
        <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold text-ink">Inside the academy</h2>
        <p class="mt-3 text-muted-foreground">Training cars, learners, and license success moments.</p>
      </div>
    <?php endif; ?>

    <div class="grid gap-3 md:gap-4 grid-cols-2 md:grid-cols-4 auto-rows-[160px] md:auto-rows-[200px]">
      <?php foreach ($items as $it): ?>
        <div class="reveal relative overflow-hidden rounded-2xl group <?= $it['span'] ?>">
          <img src="/assets/images/<?= htmlspecialchars($it['src']) ?>"
               alt="<?= htmlspecialchars($it['alt']) ?>"
               loading="lazy"
               class="absolute inset-0 h-full w-full object-cover group-hover:scale-110 transition-transform duration-700" />
          <div class="absolute inset-0 bg-gradient-to-t from-ink/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div class="absolute bottom-3 left-3 right-3 text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
            <?= htmlspecialchars($it['alt']) ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
