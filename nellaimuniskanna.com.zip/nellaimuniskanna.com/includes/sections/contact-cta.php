<section class="py-20 md:py-28 bg-surface">
  <div class="mx-auto max-w-7xl px-4 grid gap-8 lg:grid-cols-2">

    <!-- Info card -->
    <div class="rounded-3xl bg-ink text-white p-8 md:p-10 shadow-glow relative overflow-hidden">
      <div class="absolute -top-20 -right-20 h-64 w-64 rounded-full bg-yellow/15 blur-3xl"></div>
      <div class="relative">
        <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow">Get in touch</span>
        <h2 class="mt-3 text-4xl font-display font-bold leading-tight">
          Ready to start? <br />
          <span class="text-gradient-yellow">Let's talk.</span>
        </h2>
        <p class="mt-4 text-white/70">
          Call, WhatsApp, or visit us at Tirunelveli Junction. We respond within minutes.
        </p>

        <div class="mt-8 space-y-4">
          <div class="flex items-center gap-4">
            <span class="h-12 w-12 rounded-2xl bg-gradient-yellow flex items-center justify-center text-ink shrink-0">
              <?= icon('phone', 'size-5') ?>
            </span>
            <div>
              <div class="text-xs uppercase tracking-widest text-yellow">Call us</div>
              <a href="tel:<?= SITE_PHONE_TEL ?>" class="font-display font-semibold text-lg hover:text-yellow transition-colors block"><?= SITE_PHONE ?></a>
              <a href="tel:<?= SITE_PHONE2_TEL ?>" class="font-display font-semibold text-lg hover:text-yellow transition-colors block"><?= SITE_PHONE2 ?></a>
            </div>
          </div>
          <div class="flex items-center gap-4">
            <span class="h-12 w-12 rounded-2xl glass flex items-center justify-center text-yellow shrink-0">
              <?= icon('map-pin', 'size-5') ?>
            </span>
            <div>
              <div class="text-xs uppercase tracking-widest text-yellow">Visit</div>
              <div class="font-medium"><?= SITE_ADDRESS ?></div>
            </div>
          </div>
          <div class="flex items-center gap-4">
            <span class="h-12 w-12 rounded-2xl glass flex items-center justify-center text-yellow shrink-0">
              <?= icon('clock', 'size-5') ?>
            </span>
            <div>
              <div class="text-xs uppercase tracking-widest text-yellow">Hours</div>
              <div class="font-medium text-sm"><?= SITE_HOURS ?></div>
            </div>
          </div>
        </div>

        <div class="mt-8 flex flex-wrap gap-3">
          <a href="<?= wa_link() ?>" target="_blank" rel="noreferrer">
            <button class="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold bg-whatsapp text-white hover:opacity-90 transition-opacity">
              <?= icon('message-circle', 'size-4') ?> WhatsApp
            </button>
          </a>
          <a href="/book-demo">
            <button class="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity">
              Book Demo
            </button>
          </a>
        </div>
      </div>
    </div>

    <!-- Map -->
    <div class="rounded-3xl overflow-hidden border border-border shadow-card min-h-[420px] bg-card">
      <iframe
        title="Sri Munis Kanna Driving School location"
        src="<?= SITE_MAPS_EMBED ?>"
        class="w-full h-full min-h-[420px]"
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

  </div>
</section>
