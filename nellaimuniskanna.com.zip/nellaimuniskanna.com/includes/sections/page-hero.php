<?php
// Variables: $eyebrow, $title, $subtitle (optional)
$eyebrow  = $eyebrow  ?? '';
$title    = $title    ?? '';
$subtitle = $subtitle ?? '';
?>
<section class="relative pt-36 pb-20 md:pt-44 md:pb-28 bg-ink text-white overflow-hidden">
  <div class="absolute inset-0 pointer-events-none stripe-yellow" style="opacity:0.06"></div>
  <div class="absolute -top-40 left-0 h-96 w-96 rounded-full bg-yellow/10 blur-3xl"></div>
  <div class="absolute -bottom-20 right-0 h-64 w-64 rounded-full bg-yellow/10 blur-3xl"></div>

  <div class="relative mx-auto max-w-4xl px-4 text-center fade-in-up">
    <?php if ($eyebrow): ?>
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow"><?= htmlspecialchars($eyebrow) ?></span>
    <?php endif; ?>
    <h1 class="mt-4 text-4xl sm:text-5xl md:text-6xl font-display font-bold leading-tight">
      <?= htmlspecialchars($title) ?>
    </h1>
    <?php if ($subtitle): ?>
      <p class="mt-5 text-lg md:text-xl text-white/70 max-w-2xl mx-auto"><?= htmlspecialchars($subtitle) ?></p>
    <?php endif; ?>
  </div>
</section>
