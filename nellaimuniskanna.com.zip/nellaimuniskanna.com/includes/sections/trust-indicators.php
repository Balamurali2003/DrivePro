<?php
$items = [
    ['icon' => 'award',       'title' => '22 Practical Classes',     'desc' => 'Structured curriculum from basics to highway.'],
    ['icon' => 'users',       'title' => 'Experienced Trainers',     'desc' => 'Patient instructors with 15+ years on Tirunelveli roads.'],
    ['icon' => 'heart',       'title' => 'Ladies Special Coaching',  'desc' => 'Female-friendly, comfort-first sessions.'],
    ['icon' => 'clock',       'title' => 'Flexible Timings',         'desc' => 'Early morning to evening — choose your slot.'],
    ['icon' => 'map',         'title' => 'Real Road Practice',       'desc' => 'Junctions, traffic signals, parking & highways.'],
    ['icon' => 'badge-check', 'title' => 'License Assistance',       'desc' => 'End-to-end help from LL to permanent license.'],
];
?>
<section class="relative py-20 md:py-28 bg-surface">
  <div class="mx-auto max-w-7xl px-4">
    <div class="text-center max-w-2xl mx-auto mb-14">
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">What you get</span>
      <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold text-ink">Built for confident drivers</h2>
    </div>

    <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      <?php foreach ($items as $it): ?>
        <div class="reveal group relative rounded-3xl bg-card p-7 shadow-card hover:shadow-glow transition-all duration-500 border border-border/60 overflow-hidden">
          <div class="absolute -top-10 -right-10 h-32 w-32 rounded-full bg-yellow/0 group-hover:bg-yellow/15 blur-2xl transition-all duration-500"></div>
          <div class="relative">
            <div class="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-ink text-yellow group-hover:bg-gradient-yellow group-hover:text-ink transition-all duration-300">
              <?= icon($it['icon'], 'size-5') ?>
            </div>
            <h3 class="mt-5 text-xl font-display font-semibold text-ink"><?= htmlspecialchars($it['title']) ?></h3>
            <p class="mt-2 text-sm text-muted-foreground leading-relaxed"><?= htmlspecialchars($it['desc']) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
