<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-3xl px-4">
    <div class="rounded-3xl bg-card border border-border shadow-glow p-8 md:p-12">
      <div class="text-center mb-8">
        <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">Send enquiry</span>
        <h2 class="mt-2 text-3xl md:text-4xl font-display font-bold text-ink">Tell us how we can help</h2>
      </div>

      <div id="contact-success" style="display:none" class="mb-6 rounded-2xl bg-green-50 border border-green-200 px-5 py-4 text-green-800 text-sm font-medium text-center">
        Thank you! We'll be in touch shortly.
      </div>

      <form id="contact-form" class="space-y-5" novalidate>
        <div>
          <label for="contact-name" class="block text-sm font-medium text-ink mb-1.5">Your name</label>
          <input id="contact-name" name="name" type="text" placeholder="e.g. Priya Ravi" required
                 class="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div>
          <label for="contact-phone" class="block text-sm font-medium text-ink mb-1.5">Phone / WhatsApp</label>
          <input id="contact-phone" name="phone" type="tel" placeholder="+91 98XXXXXXXX" required
                 class="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <div>
          <label for="contact-message" class="block text-sm font-medium text-ink mb-1.5">What would you like to know?</label>
          <textarea id="contact-message" name="message" rows="4" placeholder="I'm interested in the ladies special course…" required
                    class="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"></textarea>
        </div>
        <button type="submit" id="contact-submit"
                class="w-full inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-base font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity shadow-glow">
          <?= icon('message-circle', 'size-4') ?> Enquire
        </button>
        <p class="text-xs text-muted-foreground text-center">
          Or call us at
          <a class="font-semibold text-ink" href="tel:<?= SITE_PHONE_TEL ?>"><?= SITE_PHONE ?></a>
          &nbsp;/&nbsp;
          <a class="font-semibold text-ink" href="tel:<?= SITE_PHONE2_TEL ?>"><?= SITE_PHONE2 ?></a>
        </p>
      </form>
    </div>
  </div>
</section>

<script>
document.getElementById('contact-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var name    = this.querySelector('[name="name"]').value.trim();
  var phone   = this.querySelector('[name="phone"]').value.trim();
  var message = this.querySelector('[name="message"]').value.trim();

  if (name.length < 2 || phone.length < 8 || !message) {
    alert('Please fill all fields correctly.');
    return;
  }

  var btn = document.getElementById('contact-submit');
  btn.disabled = true;
  btn.textContent = 'Sending…';

  var fd = new FormData();
  fd.append('name',    name);
  fd.append('phone',   phone);
  fd.append('message', message);
  fd.append('source',  'contact');

  fetch('/enquiry', { method: 'POST', body: fd })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      document.getElementById('contact-success').style.display = 'block';
      document.getElementById('contact-form').reset();
      btn.disabled = false;
      btn.innerHTML = '<?= addslashes(icon('message-circle', 'size-4')) ?> Enquire';
      if (data.wa_url) {
        window.open(data.wa_url, '_blank');
      }
    })
    .catch(function() {
      btn.disabled = false;
      btn.innerHTML = '<?= addslashes(icon('message-circle', 'size-4')) ?> Enquire';
      alert('Something went wrong. Please call us directly.');
    });
});
</script>
