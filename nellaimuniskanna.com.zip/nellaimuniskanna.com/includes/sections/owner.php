<section class="py-20 md:py-28 bg-ink text-white relative overflow-hidden">
  <div class="absolute -top-40 -left-40 h-96 w-96 rounded-full bg-yellow/15 blur-3xl"></div>
  <div class="absolute -bottom-40 -right-40 h-96 w-96 rounded-full bg-yellow/10 blur-3xl"></div>

  <div class="relative mx-auto max-w-7xl px-4 grid gap-12 lg:grid-cols-2 items-center">

    <div class="reveal relative max-w-md mx-auto lg:mx-0">
      <div class="absolute -inset-4 rounded-[2rem] bg-gradient-yellow blur-xl opacity-40"></div>
      <div class="relative rounded-[2rem] overflow-hidden border border-yellow/30">
        <img src="/assets/images/owner.jpg" alt="M. Muthukumar - Owner &amp; Lead Trainer"
             loading="lazy" width="1024" height="1280"
             class="w-full aspect-[4/5] object-cover" />
        <div class="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-ink via-ink/70 to-transparent">
          <div class="inline-flex items-center gap-2 glass rounded-full px-3 py-1 text-xs">
            <?= icon('award', 'size-3 text-yellow') ?> Founder &amp; Lead Trainer
          </div>
          <div class="mt-3 text-2xl font-display font-bold"><?= SITE_OWNER ?></div>
        </div>
      </div>
    </div>

    <div class="reveal">
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow">Meet our owner</span>
      <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold leading-tight">
        Driven by a mission for <span class="text-gradient-yellow">safer roads</span>
      </h2>

      <div class="mt-8 relative pl-6">
        <?= icon('quote', 'absolute -left-2 top-0 size-8 text-yellow/40') ?>
        <p class="text-lg text-white/85 leading-relaxed">
          "A driving license is just a card. What matters is whether you can handle a sudden stop, a busy junction, or a rainy night with calm hands. That's what we teach here — and that's why families trust us with their first-time drivers."
        </p>
        <p class="mt-4 text-sm text-yellow font-medium">— <?= SITE_OWNER ?>, Founder</p>
      </div>

      <div class="mt-10 grid grid-cols-3 gap-4">
        <?php
        $stats = [
            ['v' => '15+', 'l' => 'Years experience'],
            ['v' => '500+', 'l' => 'Drivers trained'],
            ['v' => '98%', 'l' => 'Test pass rate'],
        ];
        foreach ($stats as $s): ?>
          <div class="glass rounded-2xl p-5 text-center">
            <div class="text-3xl font-display font-bold text-yellow"><?= $s['v'] ?></div>
            <div class="text-xs text-white/60 mt-1"><?= $s['l'] ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</section>
