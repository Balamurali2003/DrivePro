<?php require_once __DIR__ . '/../../data/testimonials.php'; ?>
<section class="py-20 md:py-28 bg-surface relative overflow-hidden">
  <div class="mx-auto max-w-7xl px-4">
    <div class="text-center max-w-2xl mx-auto mb-14">
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">Success stories</span>
      <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold text-ink">
        Hundreds of confident drivers, <span class="text-gradient-yellow">one academy</span>
      </h2>
    </div>

    <div class="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      <?php foreach (TESTIMONIALS as $t): ?>
        <div class="reveal rounded-3xl bg-card border border-border p-7 shadow-card hover:shadow-glow hover:-translate-y-1 transition-all duration-500 relative">
          <?= icon('quote', 'absolute top-5 right-5 size-8 text-yellow/30') ?>
          <div class="flex gap-0.5">
            <?= str_repeat(icon('star', 'size-4 fill-yellow text-yellow'), (int)$t['rating']) ?>
          </div>
          <p class="mt-4 text-ink leading-relaxed">"<?= htmlspecialchars($t['quote']) ?>"</p>
          <div class="mt-6 pt-5 border-t border-border flex items-center gap-3">
            <div class="h-11 w-11 rounded-full bg-gradient-yellow flex items-center justify-center font-display font-bold text-ink">
              <?= htmlspecialchars(mb_substr($t['name'], 0, 1)) ?>
            </div>
            <div>
              <div class="font-display font-semibold text-ink"><?= htmlspecialchars($t['name']) ?></div>
              <div class="text-xs text-muted-foreground"><?= htmlspecialchars($t['role']) ?></div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
