<?php
$posts = get_blog_posts(3);
?>
<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-7xl px-4">
    <div class="flex items-end justify-between flex-wrap gap-6 mb-12">
      <div class="max-w-2xl">
        <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">Blog &amp; driving tips</span>
        <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold text-ink">Drive smarter, every day</h2>
      </div>
      <a href="/blog" class="text-sm font-medium text-ink hover:text-yellow-deep flex items-center gap-1">
        See all articles <?= icon('arrow-up-right', 'size-4') ?>
      </a>
    </div>

    <div class="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
      <?php foreach ($posts as $p):
        $tag = $p['tags'][0] ?? 'Blog';
      ?>
        <a href="/blog/<?= htmlspecialchars($p['slug']) ?>"
           class="reveal group rounded-3xl overflow-hidden bg-card border border-border shadow-card hover:shadow-glow transition-all duration-500 hover:-translate-y-1 block no-underline">
          <div class="aspect-[16/10] bg-gradient-to-br from-ink via-ink-soft to-ink relative overflow-hidden">
            <?php if (!empty($p['image_url'])): ?>
            <img src="<?= htmlspecialchars($p['image_url']) ?>"
                 alt="<?= htmlspecialchars($p['title']) ?>"
                 class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                 style="position:absolute;inset:0;">
            <div class="absolute inset-0" style="background:linear-gradient(to top,rgba(0,0,0,.45) 0%,transparent 60%)"></div>
            <?php else: ?>
            <div class="absolute inset-0 stripe-yellow" style="opacity:0.08"></div>
            <div class="absolute inset-0 flex items-center justify-center text-yellow font-display font-bold text-4xl opacity-30 group-hover:opacity-100 transition-opacity">
              <?= htmlspecialchars($tag) ?>
            </div>
            <?php endif; ?>
            <span class="absolute top-4 left-4 text-[10px] uppercase tracking-widest bg-yellow text-ink font-semibold px-3 py-1 rounded-full">
              <?= htmlspecialchars($tag) ?>
            </span>
          </div>
          <div class="p-6">
            <h3 class="font-display font-bold text-xl text-ink leading-tight group-hover:text-yellow-deep transition-colors">
              <?= htmlspecialchars($p['title']) ?>
            </h3>
            <p class="mt-2 text-sm text-muted-foreground"><?= htmlspecialchars($p['excerpt']) ?></p>
            <div class="mt-5 text-xs text-muted-foreground flex items-center justify-between">
              <span><?= htmlspecialchars($p['read'] ?? ($p['publishedAt'] ?: '')) ?></span>
              <?= icon('arrow-up-right', 'size-4 text-yellow-deep') ?>
            </div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
