<?php require_once __DIR__ . '/../../data/faqs.php'; ?>
<section class="py-20 md:py-28 bg-surface">
  <div class="mx-auto max-w-3xl px-4">
    <div class="text-center mb-12">
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow-deep">FAQ</span>
      <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold text-ink">Questions, answered</h2>
    </div>

    <div class="space-y-3" id="faq-accordion">
      <?php foreach (FAQS as $i => $f): ?>
        <div class="faq-item rounded-2xl bg-card border border-border px-5 shadow-card transition-shadow" data-index="<?= $i ?>">
          <button
            class="faq-trigger w-full text-left font-display font-semibold text-ink flex items-center justify-between py-5 gap-4"
            aria-expanded="false"
            onclick="toggleFaq(this)">
            <span><?= htmlspecialchars($f['q']) ?></span>
            <svg class="faq-chevron size-4 shrink-0 transition-transform duration-200" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="m6 9 6 6 6-6"/>
            </svg>
          </button>
          <div class="faq-content hidden pb-5 text-muted-foreground leading-relaxed">
            <?= htmlspecialchars($f['a']) ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<script>
function toggleFaq(btn) {
  const item    = btn.closest('.faq-item');
  const content = item.querySelector('.faq-content');
  const chevron = item.querySelector('.faq-chevron');
  const isOpen  = btn.getAttribute('aria-expanded') === 'true';

  // Close all
  document.querySelectorAll('.faq-item').forEach(el => {
    el.querySelector('.faq-content').classList.add('hidden');
    el.querySelector('.faq-trigger').setAttribute('aria-expanded', 'false');
    el.querySelector('.faq-chevron').style.transform = '';
    el.classList.remove('shadow-glow');
  });

  if (!isOpen) {
    content.classList.remove('hidden');
    btn.setAttribute('aria-expanded', 'true');
    chevron.style.transform = 'rotate(180deg)';
    item.classList.add('shadow-glow');
  }
}
</script>
