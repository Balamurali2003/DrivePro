<section class="relative min-h-[100svh] w-full overflow-hidden bg-ink text-white flex items-end">
  <!-- Background image -->
  <div class="absolute inset-0">
    <img src="/assets/images/hero-car.jpg" alt="Premium driving school car at golden hour"
         class="absolute inset-0 h-full w-full object-cover scale-105" width="1920" height="1080" />
    <div class="absolute inset-0 bg-gradient-overlay"></div>
    <div class="absolute inset-0 bg-gradient-to-r from-ink/80 via-ink/40 to-transparent"></div>
  </div>

  <!-- Floating yellow blobs -->
  <div class="absolute -top-20 -left-20 h-72 w-72 rounded-full bg-yellow/30 blur-3xl animate-drift"></div>
  <div class="absolute top-1/3 -right-20 h-96 w-96 rounded-full bg-yellow/20 blur-3xl animate-drift" style="animation-delay:2s"></div>

  <!-- Content -->
  <div class="relative z-10 mx-auto max-w-7xl w-full px-4 pt-32 pb-24 md:pb-32 fade-in-up">
    <div class="max-w-3xl">
      <span class="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs font-medium tracking-wide uppercase">
        <?= icon('shield-check', 'size-3.5 text-yellow') ?>
        Tirunelveli's Trusted Driving Academy
      </span>

      <h1 class="mt-6 text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-display font-bold leading-[0.95] tracking-tight">
        Learn Driving with<br />
        <span class="text-gradient-yellow">Confidence &amp; Safety</span>
      </h1>

      <p class="mt-6 text-lg md:text-xl text-white/85 font-display max-w-2xl">
        "லைசன்ஸ் மட்டும் இல்ல…<span class="text-yellow"> Perfect Driving Skill</span> உங்களுக்காக!"
      </p>

      <p class="mt-3 text-white/65 max-w-xl">
        22 practical classes &bull; Real-road training &bull; Ladies special coaching &bull; Complete license assistance.
      </p>

      <div class="mt-8 flex flex-wrap gap-3">
        <a href="tel:<?= SITE_PHONE_TEL ?>">
          <button class="inline-flex items-center gap-2 rounded-full px-6 py-3 text-base font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity shadow-glow">
            <?= icon('phone', 'size-4') ?> Call Now
          </button>
        </a>
        <a href="<?= wa_link() ?>" target="_blank" rel="noreferrer">
          <button class="inline-flex items-center gap-2 rounded-full px-6 py-3 text-base font-semibold bg-whatsapp text-white hover:opacity-90 transition-opacity">
            <?= icon('message-circle', 'size-4') ?> WhatsApp Us
          </button>
        </a>
        <a href="/book-demo">
          <button class="inline-flex items-center gap-2 rounded-full px-6 py-3 text-base font-semibold glass text-white hover:bg-white/10 transition-colors">
            Book Free Demo
          </button>
        </a>
      </div>

      <div class="mt-10 flex items-center gap-6 text-sm text-white/70">
        <div class="flex items-center gap-1.5">
          <?= str_repeat(icon('star', 'size-4 fill-yellow text-yellow'), 5) ?>
          <span class="ml-1">4.9 / 5 from learners</span>
        </div>
        <div class="hidden sm:block h-4 w-px bg-white/20"></div>
        <span class="hidden sm:inline">500+ licenses delivered</span>
      </div>
    </div>
  </div>

  <!-- Scroll indicator -->
  <div class="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 hidden md:flex flex-col items-center text-white/60">
    <span class="text-[10px] uppercase tracking-[0.2em] mb-2">Scroll</span>
    <div class="h-10 w-6 rounded-full border border-white/30 flex justify-center pt-1.5">
      <?= icon('chevron-down', 'size-3 animate-scroll-down') ?>
    </div>
  </div>
</section>
