<?php
$steps = [
    ['icon' => 'file-text',      't' => 'Registration',       'd' => 'Quick enrollment, document check, course selection.'],
    ['icon' => 'id-card',        't' => "Learner's License",   'd' => 'We handle the LL slot booking and online test prep.'],
    ['icon' => 'car',            't' => 'Practical Classes',   'd' => '22 structured sessions on real Tirunelveli roads.'],
    ['icon' => 'route',          't' => 'Road Training',       'd' => 'Junctions, signals, parking, highway exposure.'],
    ['icon' => 'clipboard-check','t' => 'Driving Test',        'd' => 'Mock tests + RTO test day support.'],
    ['icon' => 'badge-check',    't' => 'Permanent License',   'd' => 'End-to-end follow-up till your DL is in your hand.'],
];
?>
<section class="py-20 md:py-28 bg-ink text-white relative overflow-hidden">
  <div class="absolute inset-0 pointer-events-none stripe-yellow" style="opacity:0.04"></div>
  <div class="mx-auto max-w-7xl px-4 relative">
    <div class="text-center max-w-2xl mx-auto mb-16">
      <span class="text-xs font-semibold uppercase tracking-[0.2em] text-yellow">License journey</span>
      <h2 class="mt-3 text-4xl md:text-5xl font-display font-bold">
        From zero to license — <span class="text-gradient-yellow">we handle it all</span>
      </h2>
    </div>

    <div class="relative">
      <div class="hidden lg:block absolute top-12 left-0 right-0 h-px bg-gradient-to-r from-transparent via-yellow/40 to-transparent"></div>
      <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-6">
        <?php foreach ($steps as $i => $s): ?>
          <div class="reveal relative text-center">
            <div class="relative mx-auto h-24 w-24">
              <div class="absolute inset-0 rounded-full bg-yellow/20 blur-xl"></div>
              <div class="relative h-24 w-24 rounded-full bg-ink border-2 border-yellow flex items-center justify-center">
                <?= icon($s['icon'], 'size-8 text-yellow') ?>
                <span class="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-gradient-yellow text-ink text-xs font-bold flex items-center justify-center">
                  <?= $i + 1 ?>
                </span>
              </div>
            </div>
            <h3 class="mt-5 font-display font-semibold text-lg"><?= htmlspecialchars($s['t']) ?></h3>
            <p class="mt-2 text-sm text-white/60 px-2"><?= htmlspecialchars($s['d']) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
