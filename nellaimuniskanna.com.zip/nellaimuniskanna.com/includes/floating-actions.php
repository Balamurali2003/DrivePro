<!-- Mobile sticky call bar -->
<div class="fixed bottom-0 inset-x-0 z-40 md:hidden">
  <div class="grid grid-cols-2 gap-px bg-ink/10 backdrop-blur-md border-t border-border">
    <a href="tel:<?= SITE_PHONE_TEL ?>" class="flex items-center justify-center gap-2 py-3.5 bg-ink text-white font-semibold text-sm">
      <?= icon('phone', 'size-4') ?> Call Now
    </a>
    <a href="<?= wa_link() ?>" target="_blank" rel="noreferrer" class="flex items-center justify-center gap-2 py-3.5 bg-whatsapp text-white font-semibold text-sm">
      <?= icon('message-circle', 'size-4') ?> WhatsApp
    </a>
  </div>
</div>

<!-- Desktop floating WhatsApp -->
<a href="<?= wa_link() ?>" target="_blank" rel="noreferrer"
   class="hidden md:flex fixed bottom-6 right-6 z-40 h-14 w-14 rounded-full bg-whatsapp text-white items-center justify-center shadow-glow hover:scale-110 transition-transform"
   aria-label="Chat on WhatsApp">
  <span class="absolute inset-0 rounded-full bg-whatsapp animate-pulse-ring"></span>
  <?= icon('message-circle', 'size-6 relative') ?>
</a>
