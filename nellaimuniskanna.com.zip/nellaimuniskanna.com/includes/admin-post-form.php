<?php
// Shared form fields for create.php and edit.php — $data array injected by caller
$has_image = !empty($data['image_url']);
?>

<!-- ── Cover image ──────────────────────────────────────────────────────────── -->
<div style="border-bottom:1px solid var(--bdr);padding-bottom:22px;margin-bottom:4px">
  <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:14px">
    Cover Image
  </div>

  <!-- Current image preview -->
  <?php if ($has_image): ?>
  <div id="img-preview-wrap" style="position:relative;display:inline-block;margin-bottom:14px">
    <img id="img-preview" src="<?= htmlspecialchars($data['image_url']) ?>"
         alt="Current cover"
         style="display:block;width:100%;max-width:340px;height:160px;object-fit:cover;border-radius:10px;border:1px solid var(--bdr)">
    <button type="button" onclick="clearImage()"
            style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,.65);color:#fff;border:none;border-radius:6px;padding:4px 8px;font-size:11px;font-weight:600;cursor:pointer;line-height:1">
      &times; Remove
    </button>
  </div>
  <?php else: ?>
  <div id="img-preview-wrap" style="display:none;margin-bottom:14px">
    <img id="img-preview" src="" alt="Preview"
         style="display:block;width:100%;max-width:340px;height:160px;object-fit:cover;border-radius:10px;border:1px solid var(--bdr)">
    <button type="button" onclick="clearImage()"
            style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,.65);color:#fff;border:none;border-radius:6px;padding:4px 8px;font-size:11px;font-weight:600;cursor:pointer;line-height:1">
      &times; Remove
    </button>
  </div>
  <?php endif; ?>

  <!-- Hidden inputs to track state -->
  <input type="hidden" name="image_url" id="image_url_input" value="<?= htmlspecialchars($data['image_url']) ?>">
  <input type="hidden" name="image_action" id="image_action" value="keep">

  <!-- Upload zone -->
  <div id="upload-zone"
       style="border:2px dashed var(--bdr);border-radius:10px;padding:28px 20px;text-align:center;cursor:pointer;transition:border-color .15s,background .15s"
       onclick="document.getElementById('image_file').click()"
       ondragover="event.preventDefault();this.style.borderColor='var(--bdr-focus)';this.style.background='rgba(245,158,11,.04)'"
       ondragleave="this.style.borderColor='';this.style.background=''"
       ondrop="handleDrop(event)">
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
         style="margin:0 auto 10px;color:var(--muted);display:block"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
    <p style="font-size:13px;font-weight:500;color:var(--text);margin-bottom:4px">Click to upload or drag & drop</p>
    <p style="font-size:11.5px;color:var(--muted)">JPEG, PNG, WebP, GIF &mdash; max <?= UPLOAD_MAX_MB ?>MB &mdash; resized to <?= IMG_MAX_W ?>&times;<?= IMG_MAX_H ?>px, saved as WebP</p>
    <input type="file" id="image_file" name="image_file" accept="image/jpeg,image/png,image/webp,image/gif"
           style="display:none" onchange="handleFileSelect(this)">
  </div>
</div>

<!-- ── Content ──────────────────────────────────────────────────────────── -->
<div style="display:flex;flex-direction:column;gap:18px">

  <div class="form-group">
    <label class="form-label" for="f-title">
      Title <span class="form-req">*</span>
    </label>
    <input class="form-input" type="text" id="f-title" name="title" required
      placeholder="e.g. How to Park Safely on Hills"
      value="<?= htmlspecialchars($data['title']) ?>"
      oninput="handleTitleInput(this.value)">
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="form-group">
      <label class="form-label" for="f-slug">Slug</label>
      <input class="form-input form-input-mono" type="text" id="f-slug" name="slug"
        placeholder="auto-generated" spellcheck="false"
        value="<?= htmlspecialchars($data['slug']) ?>"
        oninput="slugEdited=true">
      <span class="form-hint">Leave blank to auto-generate</span>
    </div>
    <div class="form-group">
      <label class="form-label" for="f-read-time">
        Read Time
        <span class="form-hint" style="font-weight:400"> — auto-calculated if blank</span>
      </label>
      <input class="form-input" type="text" id="f-read-time" name="read_time"
        placeholder="e.g. 4 min read"
        value="<?= htmlspecialchars($data['read_time']) ?>">
    </div>
  </div>

  <div class="form-group">
    <label class="form-label" for="f-excerpt">Excerpt</label>
    <textarea class="form-input form-textarea" id="f-excerpt" name="excerpt" rows="2"
      placeholder="Short summary shown on the blog card"><?= htmlspecialchars($data['excerpt']) ?></textarea>
  </div>

  <div class="form-group">
    <label class="form-label" for="f-tags">
      Tags <span class="form-hint" style="font-weight:400"> — comma-separated</span>
    </label>
    <input class="form-input" type="text" id="f-tags" name="tags"
      placeholder="Safety, Tips, Parking"
      value="<?= htmlspecialchars($data['tags']) ?>">
  </div>

  <div class="form-group">
    <label class="form-label" for="f-content">Content</label>
    <textarea class="form-input form-textarea form-textarea-code" id="f-content" name="content" rows="18"
      placeholder="Post body — plain text or HTML"><?= htmlspecialchars($data['content']) ?></textarea>
    <span class="form-hint" id="word-count-hint" style="margin-top:4px;text-align:right"></span>
  </div>

</div>

<!-- ── SEO ───────────────────────────────────────────────────────────────── -->
<div style="border-top:1px solid var(--bdr);padding-top:22px;margin-top:6px">
  <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:14px">
    SEO &amp; Meta
  </div>
  <div style="display:flex;flex-direction:column;gap:14px">
    <div class="form-group">
      <label class="form-label" for="f-seo-title">
        SEO Title <span class="form-hint" style="font-weight:400"> — defaults to post title if blank</span>
      </label>
      <input class="form-input" type="text" id="f-seo-title" name="seo_title" maxlength="70"
        placeholder="Leave blank to use post title"
        value="<?= htmlspecialchars($data['seo_title']) ?>"
        oninput="updateCounter(this,'seo-title-count',70)">
      <span class="form-hint" id="seo-title-count" style="text-align:right"></span>
    </div>
    <div class="form-group">
      <label class="form-label" for="f-seo-desc">
        Meta Description <span class="form-hint" style="font-weight:400"> — defaults to excerpt if blank</span>
      </label>
      <textarea class="form-input form-textarea" id="f-seo-desc" name="seo_description" rows="2" maxlength="160"
        placeholder="Leave blank to use excerpt"
        oninput="updateCounter(this,'seo-desc-count',160)"><?= htmlspecialchars($data['seo_description']) ?></textarea>
      <span class="form-hint" id="seo-desc-count" style="text-align:right"></span>
    </div>
  </div>
</div>

<!-- ── Publish settings ──────────────────────────────────────────────────── -->
<div style="border-top:1px solid var(--bdr);padding-top:22px;margin-top:6px">
  <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:14px">
    Publish Settings
  </div>
  <div style="display:flex;flex-direction:column;gap:12px">
    <label class="form-toggle-row" for="f-published" style="cursor:pointer">
      <input type="checkbox" id="f-published" name="published" value="1"
        <?= $data['published'] ? 'checked' : '' ?>
        onchange="toggleScheduleRow(this.checked)">
      <div>
        <div class="form-toggle-label">Publish this post</div>
        <div class="form-toggle-desc">Unchecked saves as draft. Set a future date to schedule.</div>
      </div>
    </label>
    <div class="form-group" id="schedule-row" style="<?= $data['published'] ? '' : 'display:none' ?>">
      <label class="form-label" for="f-published-at">
        Publish date &amp; time
        <span class="form-hint" style="font-weight:400"> — future = scheduled, past/now = live immediately</span>
      </label>
      <input class="form-input" type="datetime-local" id="f-published-at" name="published_at"
        value="<?= $data['published_at'] ? date('Y-m-d\TH:i', strtotime($data['published_at'])) : date('Y-m-d\TH:i') ?>">
    </div>
  </div>
</div>

<script>
(function () {
  var slugEdited = <?= json_encode($data['slug'] !== '') ?>;
  window.slugEdited = slugEdited;

  window.handleTitleInput = function (val) {
    if (!window.slugEdited) {
      document.getElementById('f-slug').value = val.toLowerCase().trim()
        .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    }
    updateWordCount();
  };

  window.toggleScheduleRow = function (checked) {
    document.getElementById('schedule-row').style.display = checked ? '' : 'none';
  };

  window.updateCounter = function (el, id, max) {
    var len = el.value.length;
    var out = document.getElementById(id);
    out.textContent = len + ' / ' + max;
    out.style.color = len > max * 0.9 ? '#DC2626' : '#A1A1AA';
  };

  function updateWordCount() {
    var ta = document.getElementById('f-content');
    if (!ta) return;
    var words = ta.value.trim().split(/\s+/).filter(Boolean).length;
    var mins  = Math.max(1, Math.ceil(words / 200));
    var hint  = document.getElementById('word-count-hint');
    if (hint) hint.textContent = words + ' words · ~' + mins + ' min read';
  }

  // Image upload handling
  window.handleFileSelect = function (input) {
    if (!input.files || !input.files[0]) return;
    previewFile(input.files[0]);
  };

  window.handleDrop = function (e) {
    e.preventDefault();
    document.getElementById('upload-zone').style.borderColor = '';
    document.getElementById('upload-zone').style.background  = '';
    var file = e.dataTransfer.files[0];
    if (!file || !file.type.startsWith('image/')) return;
    // Transfer to file input
    var dt = new DataTransfer();
    dt.items.add(file);
    document.getElementById('image_file').files = dt.files;
    previewFile(file);
  };

  function previewFile(file) {
    var reader = new FileReader();
    reader.onload = function (ev) {
      var wrap = document.getElementById('img-preview-wrap');
      var img  = document.getElementById('img-preview');
      img.src  = ev.target.result;
      wrap.style.display = 'inline-block';
      wrap.style.position = 'relative';
      document.getElementById('image_action').value = 'replace';
      document.getElementById('image_url_input').value = '';
    };
    reader.readAsDataURL(file);
  }

  window.clearImage = function () {
    document.getElementById('img-preview-wrap').style.display  = 'none';
    document.getElementById('img-preview').src                 = '';
    document.getElementById('image_action').value              = 'clear';
    document.getElementById('image_url_input').value           = '';
    document.getElementById('image_file').value                = '';
  };

  // Init counters
  ['f-seo-title','f-seo-desc'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el && el.value) {
      var max = id === 'f-seo-title' ? 70 : 160;
      var cid = id === 'f-seo-title' ? 'seo-title-count' : 'seo-desc-count';
      updateCounter(el, cid, max);
    }
  });

  document.getElementById('f-content')?.addEventListener('input', updateWordCount);
  document.getElementById('f-slug')?.addEventListener('input', function() { window.slugEdited = true; });
  updateWordCount();
})();
</script>
