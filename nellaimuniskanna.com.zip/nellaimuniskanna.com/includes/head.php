<?php
$meta        = $meta ?? [];
$page_title  = htmlspecialchars($meta['title'] ?? 'Sri Munis Kanna Driving School');
$page_desc   = htmlspecialchars($meta['description'] ?? 'Premium driving school at Tirunelveli Junction. 22 practical classes, ladies special coaching, real-road training & complete license assistance.');
$og_title    = htmlspecialchars($meta['og_title']       ?? ($meta['title'] ?? 'Sri Munis Kanna Driving School'));
$og_desc     = htmlspecialchars($meta['og_description'] ?? ($meta['description'] ?? ''));
$og_image    = htmlspecialchars(!empty($meta['og_image']) ? (SITE_URL . $meta['og_image']) : (SITE_URL . '/assets/og.jpg'));
$og_type     = htmlspecialchars($meta['og_type'] ?? 'website');
$canonical   = !empty($meta['canonical']) ? htmlspecialchars(SITE_URL . $meta['canonical']) : '';
$og_url      = $canonical ?: htmlspecialchars(SITE_URL . '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title><?= $page_title ?></title>
  <meta name="description" content="<?= $page_desc ?>" />
  <?php if (!empty($meta['robots'])): ?>
  <meta name="robots" content="<?= htmlspecialchars($meta['robots']) ?>" />
  <?php endif; ?>

  <!-- Open Graph -->
  <meta property="og:site_name" content="<?= htmlspecialchars(SITE_NAME) ?>" />
  <meta property="og:type"        content="<?= $og_type ?>" />
  <meta property="og:title"       content="<?= $og_title ?>" />
  <meta property="og:description" content="<?= $og_desc ?>" />
  <meta property="og:image"       content="<?= $og_image ?>" />
  <meta property="og:url"         content="<?= $og_url ?>" />

  <!-- Twitter Card -->
  <meta name="twitter:card"        content="summary_large_image" />
  <meta name="twitter:title"       content="<?= $og_title ?>" />
  <meta name="twitter:description" content="<?= $og_desc ?>" />
  <meta name="twitter:image"       content="<?= $og_image ?>" />

  <?php if ($canonical): ?>
  <link rel="canonical" href="<?= $canonical ?>" />
  <?php endif; ?>

  <link rel="icon" href="/assets/favicon.svg" type="image/svg+xml" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />

  <link rel="stylesheet" href="/assets/css/styles.css" />

  <style>
    /* Pagination — used on /blog and post pages */
    .pagination { display:flex; align-items:center; justify-content:center; gap:4px; flex-wrap:wrap; }
    .pg-btn {
      display:inline-flex; align-items:center; justify-content:center;
      min-width:36px; height:36px; padding:0 4px;
      border-radius:8px; font-size:14px; font-weight:500;
      color: var(--color-muted-foreground, #6b7280);
      text-decoration:none;
      transition: background .15s, color .15s;
    }
    .pg-btn:hover { background: var(--color-card, #fff); color: var(--color-foreground, #111); }
    .pg-current {
      background: var(--color-yellow, #FBBF24);
      color: #111 !important;
      font-weight:600;
      pointer-events:none;
    }
    .pg-disabled { opacity:.35; pointer-events:none; cursor:default; }
    .pg-ellipsis { display:inline-flex; align-items:center; padding:0 4px; color:#9ca3af; font-size:14px; }
    .pg-arrow svg { display:block; }
  </style>

  <?php if (!empty($meta['ld_json'])): ?>
  <script type="application/ld+json"><?= $meta['ld_json'] ?></script>
  <?php endif; ?>
</head>
<body>
