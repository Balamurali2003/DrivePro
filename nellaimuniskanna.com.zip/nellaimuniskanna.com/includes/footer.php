<footer class="relative bg-ink text-white">
  <div class="absolute inset-x-0 top-0 h-2 stripe-yellow opacity-90"></div>
  <div class="mx-auto max-w-7xl px-4 pt-20 pb-10">

    <!-- CTA band -->
    <div class="rounded-3xl bg-gradient-yellow p-8 md:p-12 shadow-glow flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-16">
      <div>
        <h3 class="text-ink text-3xl md:text-4xl font-display font-bold leading-tight">Start Your Driving Journey Today</h3>
        <p class="text-ink/80 mt-2 max-w-xl">Free demo class • Real-road practice • License assistance included.</p>
      </div>
      <div class="flex flex-wrap gap-3">
        <a href="<?= wa_link() ?>" target="_blank" rel="noreferrer"
           class="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold bg-ink text-white hover:opacity-90 transition-opacity">
          <?= icon('message-circle', 'size-4') ?> WhatsApp Us
        </a>
        <a href="/book-demo"
           class="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold bg-ink text-white hover:opacity-90 transition-opacity">
          Book Free Demo
        </a>
      </div>
    </div>

    <div class="grid gap-10 md:grid-cols-4">
      <div class="md:col-span-2">
        <div class="flex items-center gap-3">
          <span class="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-yellow">
            <span class="font-display font-bold text-ink text-lg">SMK</span>
          </span>
          <div>
            <div class="font-display font-bold text-lg"><?= SITE_NAME ?></div>
            <div class="text-yellow text-xs uppercase tracking-[0.18em]">Tirunelveli's Premium Academy</div>
          </div>
        </div>
        <p class="mt-4 text-white/70 max-w-md">
          "லைசன்ஸ் மட்டும் இல்ல… Perfect Driving Skill உங்களுக்காக!" — Trusted by hundreds of learners across Tirunelveli.
        </p>
        <div class="flex items-center gap-3 mt-6">
          <a href="#" class="h-10 w-10 rounded-full glass flex items-center justify-center hover:bg-yellow hover:text-ink transition-colors">
            <?= icon('instagram', 'size-4') ?>
          </a>
          <a href="#" class="h-10 w-10 rounded-full glass flex items-center justify-center hover:bg-yellow hover:text-ink transition-colors">
            <?= icon('facebook', 'size-4') ?>
          </a>
          <a href="#" class="h-10 w-10 rounded-full glass flex items-center justify-center hover:bg-yellow hover:text-ink transition-colors">
            <?= icon('youtube', 'size-4') ?>
          </a>
        </div>
      </div>

      <div>
        <h4 class="font-display font-semibold text-yellow mb-4">Quick Links</h4>
        <ul class="space-y-2 text-sm text-white/70">
          <?php foreach (NAV as $n): ?>
            <li><a href="<?= htmlspecialchars($n['href']) ?>" class="hover:text-yellow transition-colors"><?= htmlspecialchars($n['label']) ?></a></li>
          <?php endforeach; ?>
          <li><a href="/book-demo" class="hover:text-yellow transition-colors">Book Demo</a></li>
        </ul>
      </div>

      <div>
        <h4 class="font-display font-semibold text-yellow mb-4">Get in Touch</h4>
        <ul class="space-y-3 text-sm text-white/80">
          <li class="flex gap-3">
            <?= icon('phone', 'size-4 text-yellow shrink-0 mt-0.5') ?>
            <div class="flex flex-col">
              <a href="tel:<?= SITE_PHONE_TEL ?>"><?= SITE_PHONE ?></a>
              <a href="tel:<?= SITE_PHONE2_TEL ?>"><?= SITE_PHONE2 ?></a>
            </div>
          </li>
          <li class="flex gap-3">
            <?= icon('map-pin', 'size-4 text-yellow shrink-0 mt-0.5') ?>
            <?= SITE_ADDRESS ?>
          </li>
          <li class="flex gap-3">
            <?= icon('clock', 'size-4 text-yellow shrink-0 mt-0.5') ?>
            <?= SITE_HOURS ?>
          </li>
        </ul>
      </div>
    </div>

    <div class="mt-12 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-white/50">
      <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.</p>
      <p>Owner: <?= SITE_OWNER ?> &bull; Tirunelveli, Tamil Nadu</p>
    </div>
  </div>
</footer>
