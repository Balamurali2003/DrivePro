<?php declare(strict_types=1); ?>
<?php include __DIR__ . '/head.php'; ?>

<div class="min-h-screen flex flex-col bg-background">
  <?php include __DIR__ . '/navbar.php'; ?>

  <main class="flex-1 pb-20 md:pb-0">
    <?= $content ?? '' ?>
  </main>

  <?php include __DIR__ . '/footer.php'; ?>
  <?php include __DIR__ . '/floating-actions.php'; ?>
</div>

<script src="/assets/js/main.js" defer></script>
</body>
</html>
