<?php
$current_path = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/', '/');
if ($current_path === '') $current_path = '/';
?>
<header id="navbar" class="fixed top-0 inset-x-0 z-50 transition-all duration-300 py-4">
  <div class="mx-auto max-w-7xl px-4">
    <div id="navbar-inner" class="flex items-center justify-between rounded-full px-4 md:px-6 transition-all duration-300 bg-ink/40 backdrop-blur-md border border-white/10 h-16">

      <a href="/" class="flex items-center gap-2 group">
        <span class="relative flex h-9 w-9 items-center justify-center rounded-full bg-gradient-yellow shadow-glow">
          <span class="font-display font-bold text-ink">SMK</span>
        </span>
        <span class="hidden sm:flex flex-col leading-tight font-display navbar-logo-text text-white">
          <span class="text-[13px] font-bold tracking-wide">SRI MUNIS KANNA</span>
          <span class="text-[10px] uppercase tracking-[0.18em] text-yellow">Driving School</span>
        </span>
      </a>

      <nav class="hidden lg:flex items-center gap-1">
        <?php foreach (NAV as $n): ?>
          <?php $active = ($current_path === $n['href']); ?>
          <a href="<?= htmlspecialchars($n['href']) ?>"
             class="relative px-4 py-2 text-sm font-medium rounded-full transition-colors <?= $active ? 'text-yellow nav-active' : 'text-white/80 hover:text-white' ?>">
            <?= htmlspecialchars($n['label']) ?>
            <?php if ($active): ?>
              <span class="absolute inset-0 -z-10 rounded-full bg-white/10"></span>
            <?php endif; ?>
          </a>
        <?php endforeach; ?>
      </nav>

      <div class="flex items-center gap-2">
        <div class="hidden md:flex flex-col items-end">
          <a href="tel:<?= SITE_PHONE_TEL ?>" class="inline-flex items-center gap-1.5 text-sm font-semibold navbar-phone-text text-white">
            <?= icon('phone', 'size-3.5') ?>
            <?= SITE_PHONE ?>
          </a>
          <a href="tel:<?= SITE_PHONE2_TEL ?>" class="text-xs font-medium opacity-80 hover:opacity-100 transition-opacity navbar-phone-text text-white">
            <?= SITE_PHONE2 ?>
          </a>
        </div>
        <a href="/book-demo" class="hidden sm:block">
          <button class="inline-flex items-center justify-center rounded-full px-4 py-1.5 text-sm font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity">Book Demo</button>
        </a>
        <button id="nav-toggle" class="lg:hidden rounded-full p-2 text-white hover:bg-white/10" aria-label="Toggle menu">
          <span id="nav-icon-menu"><?= icon('menu', 'size-5') ?></span>
          <span id="nav-icon-close" class="hidden"><?= icon('x', 'size-5') ?></span>
        </button>
      </div>
    </div>

    <div id="nav-mobile" class="hidden lg:hidden mt-2 rounded-3xl bg-white/90 backdrop-blur-xl border border-black/5 shadow-card overflow-hidden">
      <div class="p-2">
        <?php foreach (NAV as $n): ?>
          <?php $active = ($current_path === $n['href']); ?>
          <a href="<?= htmlspecialchars($n['href']) ?>"
             class="block px-4 py-3 rounded-2xl text-sm font-medium <?= $active ? 'bg-ink text-white' : 'text-ink hover:bg-gray-100' ?>">
            <?= htmlspecialchars($n['label']) ?>
          </a>
        <?php endforeach; ?>
        <a href="/book-demo" class="block mt-2">
          <button class="w-full inline-flex items-center justify-center rounded-full px-4 py-3 text-sm font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity">Book Free Demo</button>
        </a>
      </div>
    </div>
  </div>
</header>
