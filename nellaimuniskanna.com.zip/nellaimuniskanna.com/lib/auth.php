<?php
declare(strict_types=1);

function admin_session_start(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function is_admin_logged_in(): bool {
    admin_session_start();
    return !empty($_SESSION[ADMIN_SESSION_KEY]);
}

function require_admin_login(): void {
    if (!is_admin_logged_in()) {
        header('Location: /admin/login');
        exit;
    }
}

function admin_login(string $username, string $password): bool {
    admin_session_start();
    // Constant-time username check to prevent timing attacks
    $user_match = hash_equals(ADMIN_USER, $username);
    $pass_match = password_verify($password, ADMIN_PASS_HASH);
    if ($user_match && $pass_match) {
        session_regenerate_id(true);
        $_SESSION[ADMIN_SESSION_KEY] = true;
        $_SESSION['csrf_token']      = bin2hex(random_bytes(32));
        return true;
    }
    return false;
}

function admin_logout(): void {
    admin_session_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function csrf_token(): string {
    admin_session_start();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_verify(): void {
    $token = $_POST['_csrf'] ?? '';
    if (!hash_equals(csrf_token(), $token)) {
        http_response_code(403);
        exit('Request blocked: invalid security token. Go back and try again.');
    }
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
