<?php
declare(strict_types=1);

define('UPLOAD_DIR',    __DIR__ . '/../assets/uploads/posts/');
define('UPLOAD_URL',    '/assets/uploads/posts/');
define('UPLOAD_MAX_MB', 5);
define('IMG_MAX_W',     1200);
define('IMG_MAX_H',     800);
define('IMG_QUALITY',   82);

function handle_image_upload(array $file, string $old_url = ''): string {
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new \RuntimeException(upload_error_message($file['error']));
    }

    if ($file['size'] > UPLOAD_MAX_MB * 1024 * 1024) {
        throw new \RuntimeException('Image must be under ' . UPLOAD_MAX_MB . ' MB.');
    }

    // Validate MIME via finfo — never trust the browser-supplied type
    $finfo   = new \finfo(FILEINFO_MIME_TYPE);
    $mime    = $finfo->file($file['tmp_name']);
    $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!in_array($mime, $allowed, true)) {
        throw new \RuntimeException('Only JPEG, PNG, WebP, or GIF images are allowed.');
    }

    // Load source into GD
    if ($mime === 'image/jpeg') {
        $src = @imagecreatefromjpeg($file['tmp_name']);
    } elseif ($mime === 'image/png') {
        $src = @imagecreatefrompng($file['tmp_name']);
    } elseif ($mime === 'image/webp') {
        $src = @imagecreatefromwebp($file['tmp_name']);
    } elseif ($mime === 'image/gif') {
        $src = @imagecreatefromgif($file['tmp_name']);
    } else {
        $src = false;
    }
    if ($src === false) {
        throw new \RuntimeException('Could not read image. The file may be corrupted.');
    }

    $orig_w = imagesx($src);
    $orig_h = imagesy($src);

    // Scale down only if larger than max dimensions
    $ratio = min(IMG_MAX_W / $orig_w, IMG_MAX_H / $orig_h, 1.0);
    $new_w = max(1, (int) round($orig_w * $ratio));
    $new_h = max(1, (int) round($orig_h * $ratio));

    $dst = imagecreatetruecolor($new_w, $new_h);

    // Preserve transparency (PNG / WebP / GIF)
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    $fill = imagecolorallocatealpha($dst, 255, 255, 255, 127);
    imagefilledrectangle($dst, 0, 0, $new_w - 1, $new_h - 1, $fill);
    imagealphablending($dst, true);

    imagecopyresampled($dst, $src, 0, 0, 0, 0, $new_w, $new_h, $orig_w, $orig_h);
    imagedestroy($src);

    // Save as WebP
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }

    $filename = bin2hex(random_bytes(12)) . '.webp';
    $filepath = UPLOAD_DIR . $filename;

    if (!imagewebp($dst, $filepath, IMG_QUALITY)) {
        imagedestroy($dst);
        throw new \RuntimeException('Failed to write image to disk.');
    }
    imagedestroy($dst);

    // Delete the old uploaded file when replacing (skip external URLs)
    delete_uploaded_image($old_url);

    return UPLOAD_URL . $filename;
}

function delete_uploaded_image(string $url): void {
    if ($url === '' || !str_starts_with($url, UPLOAD_URL)) return;
    $path = UPLOAD_DIR . basename($url);
    if (is_file($path)) {
        @unlink($path);
    }
}

function upload_error_message(int $code): string {
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return 'File exceeds the maximum allowed upload size.';
        case UPLOAD_ERR_PARTIAL:
            return 'Upload was interrupted. Please try again.';
        case UPLOAD_ERR_NO_FILE:
            return 'No file was selected.';
        case UPLOAD_ERR_NO_TMP_DIR:
        case UPLOAD_ERR_CANT_WRITE:
            return 'Server storage error. Contact the administrator.';
        default:
            return 'Upload failed (error code ' . $code . ').';
    }
}
