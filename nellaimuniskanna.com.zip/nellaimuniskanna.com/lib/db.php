<?php
declare(strict_types=1);

function get_pdo(): ?\PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            DB_HOST, DB_PORT, DB_NAME,
        );
        $pdo = new \PDO($dsn, DB_USER, DB_PASS, [
            \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
            \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
            \PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (\PDOException $e) {
        $pdo = null;
    }
    return $pdo;
}

function calculate_read_time(string $content): string {
    $words   = str_word_count(strip_tags($content));
    $minutes = max(1, (int) ceil($words / 200));
    return $minutes . ' min read';
}

function post_status(array $post): string {
    if (!$post['published']) return 'draft';
    if ($post['published_at'] && strtotime($post['published_at']) > time()) return 'scheduled';
    return 'published';
}

// Session-deduplicated view counter — reloads don't increment.
function record_post_view(int $id): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $key = 'viewed_' . $id;
    if (!empty($_SESSION[$key])) return;
    $_SESSION[$key] = true;

    $pdo = get_pdo();
    if ($pdo === null) return;
    $pdo->prepare('UPDATE posts SET views = views + 1 WHERE id = :id')
        ->execute([':id' => $id]);
}

// ── Public queries ────────────────────────────────────────────────────────────

function count_blog_posts(string $search = ''): int {
    $pdo = get_pdo();
    if ($pdo === null) return 0;
    try {
        $base = "published = 1 AND (published_at IS NULL OR published_at <= NOW())";
        if ($search !== '') {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM posts WHERE {$base}
                 AND (title LIKE :s OR excerpt LIKE :s OR tags LIKE :s)"
            );
            $stmt->execute([':s' => '%' . $search . '%']);
            return (int) $stmt->fetchColumn();
        }
        return (int) $pdo->query("SELECT COUNT(*) FROM posts WHERE {$base}")->fetchColumn();
    } catch (\PDOException $e) {
        return 0;
    }
}

function get_blog_posts(int $limit = 0, int $offset = 0, bool $published_only = true, string $search = ''): array {
    $pdo = get_pdo();
    if ($pdo === null) return [];

    try {
        $base  = $published_only
            ? 'published = 1 AND (published_at IS NULL OR published_at <= NOW())'
            : '1=1';
        $where = 'WHERE ' . $base;
        $params = [];

        if ($search !== '') {
            $where   .= " AND (title LIKE :s OR excerpt LIKE :s OR tags LIKE :s)";
            $params[':s'] = '%' . $search . '%';
        }

        $sql = "SELECT id, title, slug, excerpt, image_url, read_time, tags, published_at
                FROM posts {$where} ORDER BY published_at DESC";
        if ($limit > 0) {
            $sql .= ' LIMIT ' . $limit;
            if ($offset > 0) $sql .= ' OFFSET ' . $offset;
        }

        $rows  = $pdo->query($sql)->fetchAll();
        $posts = [];

        foreach ($rows as $row) {
            $tags = [];
            if (!empty($row['tags'])) {
                $decoded = json_decode($row['tags'], true);
                $tags    = is_array($decoded) ? $decoded : [$row['tags']];
            }
            $posts[] = [
                'title'       => $row['title'],
                'slug'        => $row['slug'],
                'excerpt'     => $row['excerpt'] ?? '',
                'image_url'   => $row['image_url'] ?? '',
                'tags'        => $tags,
                'publishedAt' => $row['published_at'] ? date('d M Y', strtotime($row['published_at'])) : '',
                'read'        => $row['read_time'] ?: '',
                'content'     => '',
            ];
        }
        return $posts;
    } catch (\PDOException $e) {
        return [];
    }
}

function get_post_by_slug(string $slug): ?array {
    $pdo = get_pdo();
    if ($pdo === null) return null;

    $stmt = $pdo->prepare(
        'SELECT id, title, slug, excerpt, image_url, read_time, tags, content,
                seo_title, seo_description, published, published_at, views
         FROM posts
         WHERE slug = :slug
           AND published = 1
           AND (published_at IS NULL OR published_at <= NOW())'
    );
    $stmt->execute([':slug' => $slug]);
    $row = $stmt->fetch();
    if (!$row) return null;

    $row['tags'] = $row['tags'] ? (json_decode($row['tags'], true) ?? []) : [];
    return $row;
}

// ── Admin queries ─────────────────────────────────────────────────────────────

function count_all_posts_admin(): int {
    $pdo = get_pdo();
    if ($pdo === null) return 0;
    return (int) $pdo->query('SELECT COUNT(*) FROM posts')->fetchColumn();
}

function get_all_posts_admin(int $limit = 0, int $offset = 0): array {
    $pdo = get_pdo();
    if ($pdo === null) return [];

    $sql = 'SELECT id, title, slug, excerpt, image_url, read_time, tags, content,
                   seo_title, seo_description, published, published_at, created_at, views
            FROM posts ORDER BY created_at DESC';
    if ($limit > 0) {
        $sql .= ' LIMIT ' . $limit;
        if ($offset > 0) $sql .= ' OFFSET ' . $offset;
    }

    $rows = $pdo->query($sql)->fetchAll();
    foreach ($rows as &$row) {
        $row['tags']   = $row['tags'] ? (json_decode($row['tags'], true) ?? []) : [];
        $row['status'] = post_status($row);
    }
    return $rows;
}

function get_post_by_id(int $id): ?array {
    $pdo = get_pdo();
    if ($pdo === null) return null;

    $stmt = $pdo->prepare(
        'SELECT id, title, slug, excerpt, image_url, read_time, tags, content,
                seo_title, seo_description, published, published_at, views
         FROM posts WHERE id = :id'
    );
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if (!$row) return null;

    $row['tags'] = $row['tags'] ? (json_decode($row['tags'], true) ?? []) : [];
    return $row;
}

function create_post(array $data): int {
    $pdo = get_pdo();
    if ($pdo === null) throw new \RuntimeException('DB unavailable');

    $read_time = trim($data['read_time'] ?? '');
    if ($read_time === '' && !empty($data['content'])) {
        $read_time = calculate_read_time($data['content']);
    }

    $stmt = $pdo->prepare(
        'INSERT INTO posts
           (title, slug, excerpt, image_url, read_time, tags, content,
            seo_title, seo_description, published, published_at)
         VALUES
           (:title, :slug, :excerpt, :image_url, :read_time, :tags, :content,
            :seo_title, :seo_description, :published, :published_at)'
    );
    $stmt->execute([
        ':title'           => $data['title'],
        ':slug'            => $data['slug'],
        ':excerpt'         => $data['excerpt'] ?? '',
        ':image_url'       => $data['image_url'] ?? '',
        ':read_time'       => $read_time,
        ':tags'            => json_encode($data['tags'] ?? []),
        ':content'         => $data['content'] ?? '',
        ':seo_title'       => $data['seo_title'] ?? '',
        ':seo_description' => $data['seo_description'] ?? '',
        ':published'       => $data['published'] ? 1 : 0,
        ':published_at'    => $data['published_at'] ?: ($data['published'] ? date('Y-m-d H:i:s') : null),
    ]);
    return (int) $pdo->lastInsertId();
}

function update_post(int $id, array $data): void {
    $pdo = get_pdo();
    if ($pdo === null) throw new \RuntimeException('DB unavailable');

    $read_time = trim($data['read_time'] ?? '');
    if ($read_time === '' && !empty($data['content'])) {
        $read_time = calculate_read_time($data['content']);
    }

    $stmt = $pdo->prepare(
        'UPDATE posts SET
           title=:title, slug=:slug, excerpt=:excerpt, image_url=:image_url,
           read_time=:read_time, tags=:tags, content=:content,
           seo_title=:seo_title, seo_description=:seo_description,
           published=:published, published_at=:published_at
         WHERE id=:id'
    );
    $stmt->execute([
        ':title'           => $data['title'],
        ':slug'            => $data['slug'],
        ':excerpt'         => $data['excerpt'] ?? '',
        ':image_url'       => $data['image_url'] ?? '',
        ':read_time'       => $read_time,
        ':tags'            => json_encode($data['tags'] ?? []),
        ':content'         => $data['content'] ?? '',
        ':seo_title'       => $data['seo_title'] ?? '',
        ':seo_description' => $data['seo_description'] ?? '',
        ':published'       => $data['published'] ? 1 : 0,
        ':published_at'    => $data['published_at'] ?: ($data['published'] ? date('Y-m-d H:i:s') : null),
        ':id'              => $id,
    ]);
}

function delete_post(int $id): void {
    $pdo = get_pdo();
    if ($pdo === null) throw new \RuntimeException('DB unavailable');
    $pdo->prepare('DELETE FROM posts WHERE id = :id')->execute([':id' => $id]);
}

function slugify(string $text): string {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

// ── Pagination helper ─────────────────────────────────────────────────────────

function pagination_html(int $total, int $per_page, int $current_page, string $base_url): string {
    $total_pages = (int) ceil($total / $per_page);
    if ($total_pages <= 1) return '';

    $qs = static function (int $page) use ($base_url): string {
        $sep = str_contains($base_url, '?') ? '&' : '?';
        return $base_url . ($page > 1 ? $sep . 'page=' . $page : '');
    };

    $html = '<nav class="pagination" aria-label="Pagination">';

    // Prev
    if ($current_page > 1) {
        $html .= '<a href="' . htmlspecialchars($qs($current_page - 1)) . '" class="pg-btn pg-arrow" aria-label="Previous">'
               . '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>'
               . '</a>';
    } else {
        $html .= '<span class="pg-btn pg-arrow pg-disabled" aria-disabled="true">'
               . '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>'
               . '</span>';
    }

    // Page numbers with ellipsis
    $pages = [];
    for ($i = 1; $i <= $total_pages; $i++) {
        if ($i === 1 || $i === $total_pages
            || ($i >= $current_page - 2 && $i <= $current_page + 2)) {
            $pages[] = $i;
        }
    }

    $prev = null;
    foreach ($pages as $p) {
        if ($prev !== null && $p - $prev > 1) {
            $html .= '<span class="pg-ellipsis">&hellip;</span>';
        }
        if ($p === $current_page) {
            $html .= '<span class="pg-btn pg-current" aria-current="page">' . $p . '</span>';
        } else {
            $html .= '<a href="' . htmlspecialchars($qs($p)) . '" class="pg-btn">' . $p . '</a>';
        }
        $prev = $p;
    }

    // Next
    if ($current_page < $total_pages) {
        $html .= '<a href="' . htmlspecialchars($qs($current_page + 1)) . '" class="pg-btn pg-arrow" aria-label="Next">'
               . '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>'
               . '</a>';
    } else {
        $html .= '<span class="pg-btn pg-arrow pg-disabled" aria-disabled="true">'
               . '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>'
               . '</span>';
    }

    $html .= '</nav>';
    return $html;
}

// ── Enquiries ─────────────────────────────────────────────────────────────────

function save_enquiry(array $data): int {
    $pdo = get_pdo();
    if ($pdo === null) throw new \RuntimeException('DB unavailable');

    $stmt = $pdo->prepare(
        'INSERT INTO enquiries (name, phone, message, course, preferred_date, source)
         VALUES (:name, :phone, :message, :course, :preferred_date, :source)'
    );
    $stmt->execute([
        ':name'           => mb_substr(trim($data['name'] ?? ''), 0, 255),
        ':phone'          => mb_substr(trim($data['phone'] ?? ''), 0, 50),
        ':message'        => trim($data['message'] ?? ''),
        ':course'         => mb_substr(trim($data['course'] ?? ''), 0, 255),
        ':preferred_date' => !empty($data['preferred_date']) ? $data['preferred_date'] : null,
        ':source'         => in_array($data['source'] ?? '', ['contact','book-demo']) ? $data['source'] : 'contact',
    ]);
    return (int) $pdo->lastInsertId();
}

function get_enquiries(int $limit = 50, int $offset = 0): array {
    $pdo = get_pdo();
    if ($pdo === null) return [];

    $sql = 'SELECT * FROM enquiries ORDER BY created_at DESC';
    if ($limit > 0) {
        $sql .= ' LIMIT ' . $limit;
        if ($offset > 0) $sql .= ' OFFSET ' . $offset;
    }
    return $pdo->query($sql)->fetchAll();
}

function count_enquiries(bool $unread_only = false): int {
    $pdo = get_pdo();
    if ($pdo === null) return 0;
    $where = $unread_only ? 'WHERE is_read = 0' : '';
    return (int) $pdo->query("SELECT COUNT(*) FROM enquiries {$where}")->fetchColumn();
}

function mark_enquiry_read(int $id): void {
    $pdo = get_pdo();
    if ($pdo === null) return;
    $pdo->prepare('UPDATE enquiries SET is_read = 1 WHERE id = :id')->execute([':id' => $id]);
}

function delete_enquiry(int $id): void {
    $pdo = get_pdo();
    if ($pdo === null) return;
    $pdo->prepare('DELETE FROM enquiries WHERE id = :id')->execute([':id' => $id]);
}
