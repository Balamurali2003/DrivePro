<?php
declare(strict_types=1);

if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool {
        return strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/icons.php';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/upload.php';

$uri  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
$path = rtrim($uri, '/');
if ($path === '') $path = '/';

// ── Admin routes ──────────────────────────────────────────────────────────────

if ($path === '/admin' || str_starts_with($path, '/admin/')) {

    // Logout
    if ($path === '/admin/logout') {
        admin_logout();
        header('Location: /admin/login');
        exit;
    }

    // Login (no auth required)
    if ($path === '/admin/login') {
        include __DIR__ . '/pages/admin/login.php';
        exit;
    }

    // POST: delete post
    if (preg_match('#^/admin/posts/delete/(\d+)$#', $path, $m) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_admin_login();
        csrf_verify();
        try {
            delete_post((int) $m[1]);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Post deleted.'];
        } catch (\Exception $e) {
            $_SESSION['flash'] = ['type' => 'error', 'message' => 'Delete failed: ' . $e->getMessage()];
        }
        header('Location: /admin/posts');
        exit;
    }

    // Edit post
    if (preg_match('#^/admin/posts/edit/(\d+)$#', $path, $m)) {
        $route_params = ['id' => $m[1]];
        include __DIR__ . '/pages/admin/edit.php';
        exit;
    }

    // Create post
    if ($path === '/admin/posts/create') {
        include __DIR__ . '/pages/admin/create.php';
        exit;
    }

    // Posts list (also /admin redirects here)
    if ($path === '/admin/posts' || $path === '/admin') {
        if ($path === '/admin') {
            header('Location: /admin/posts');
            exit;
        }
        include __DIR__ . '/pages/admin/posts.php';
        exit;
    }

    // POST: mark enquiry read
    if (preg_match('#^/admin/enquiries/read/(\d+)$#', $path, $m) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_admin_login();
        csrf_verify();
        mark_enquiry_read((int) $m[1]);
        header('Location: /admin/enquiries');
        exit;
    }

    // POST: delete enquiry
    if (preg_match('#^/admin/enquiries/delete/(\d+)$#', $path, $m) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        require_admin_login();
        csrf_verify();
        delete_enquiry((int) $m[1]);
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Enquiry deleted.'];
        header('Location: /admin/enquiries');
        exit;
    }

    // Enquiries list
    if ($path === '/admin/enquiries') {
        include __DIR__ . '/pages/admin/enquiries.php';
        exit;
    }

    http_response_code(404);
    echo '<p style="font-family:sans-serif;padding:2rem">Admin page not found.</p>';
    exit;
}

// ── Enquiry submission ────────────────────────────────────────────────────────

if ($path === '/enquiry' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $name      = mb_substr(trim($_POST['name']    ?? ''), 0, 255);
    $phone     = mb_substr(trim($_POST['phone']   ?? ''), 0, 50);
    $message   = trim($_POST['message']  ?? '');
    $course    = mb_substr(trim($_POST['course']  ?? ''), 0, 255);
    $pref_date = trim($_POST['preferred_date'] ?? '');
    $source    = in_array($_POST['source'] ?? '', ['contact', 'book-demo'])
                 ? $_POST['source'] : 'contact';

    if (mb_strlen($name) < 2 || mb_strlen($phone) < 8) {
        echo json_encode(['success' => false, 'error' => 'Please provide a valid name and phone number.']);
        exit;
    }

    try {
        save_enquiry([
            'name'           => $name,
            'phone'          => $phone,
            'message'        => $message,
            'course'         => $course,
            'preferred_date' => $pref_date !== '' ? $pref_date : null,
            'source'         => $source,
        ]);

        $wa_text = "Hi! I'd like to enquire about driving classes.\n\nName: {$name}\nPhone: {$phone}";
        if ($course !== '')    $wa_text .= "\nCourse: {$course}";
        if ($pref_date !== '') $wa_text .= "\nPreferred date: {$pref_date}";
        if ($message !== '')   $wa_text .= "\nMessage: {$message}";

        echo json_encode(['success' => true, 'wa_url' => wa_link($wa_text)]);
    } catch (\Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Could not save your enquiry. Please call us directly.']);
    }
    exit;
}

// ── Blog post detail ──────────────────────────────────────────────────────────

if (preg_match('#^/blog/([a-z0-9][a-z0-9\-]{0,200})$#', $path, $m)) {
    $route_params = ['slug' => $m[1]];
    ob_start();
    include __DIR__ . '/pages/blog-post.php';
    $content = ob_get_clean();
    include __DIR__ . '/includes/layout.php';
    exit;
}

// ── Public routes ─────────────────────────────────────────────────────────────

$routes = [
    '/'             => 'home',
    '/about'        => 'about',
    '/blog'         => 'blog',
    '/courses'      => 'courses',
    '/faq'          => 'faq',
    '/gallery'      => 'gallery',
    '/contact'      => 'contact',
    '/testimonials' => 'testimonials',
    '/book-demo'    => 'book-demo',
    '/why-us'       => 'why-us',
];

$is_404 = !array_key_exists($path, $routes);
$page   = $routes[$path] ?? '404';

if ($is_404) {
    http_response_code(404);
}

// Capture page content
ob_start();
include __DIR__ . "/pages/{$page}.php";
$content = ob_get_clean();

// Render layout
include __DIR__ . '/includes/layout.php';
