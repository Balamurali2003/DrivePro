<?php

define('SITE_NAME', 'Sri Munis Kanna Driving School');
define('SITE_URL',  'https://nellaimuniskanna.com');
define('SITE_SHORT', 'SMK Driving School');
define('SITE_OWNER', 'M. Muthukumar');
define('SITE_PHONE', '+91 94877 19904');
define('SITE_PHONE_TEL', '+919487719904');
define('SITE_PHONE2', '+91 74483 20321');
define('SITE_PHONE2_TEL', '+917448320321');
define('SITE_WHATSAPP', '919487719904');
define('SITE_WHATSAPP_MSG', "Hi! I'd like to enquire about driving classes at Sri Munis Kanna Driving School.");
define('SITE_LOCATION', 'Tirunelveli Junction, Tamil Nadu');
define('SITE_ADDRESS', 'Near Tirunelveli Junction, Tirunelveli, Tamil Nadu 627001');
define('SITE_HOURS', 'Mon – Sat: 6:00 AM – 8:00 PM • Sun: 7:00 AM – 12:00 PM');
define('SITE_MAPS_EMBED', 'https://www.google.com/maps?q=Tirunelveli+Junction,+Tamil+Nadu&output=embed');

define('ADMIN_USER',       getenv('ADMIN_USER') ?: 'admin');
define('ADMIN_PASS_HASH',  getenv('ADMIN_PASS_HASH') ?: '$2y$12$MF5stOwCtxArjTC3g99UpO9UdQICMDjOPD4NJaATY6TMmV/jFFByC');
define('ADMIN_SESSION_KEY', 'smk_admin');

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'smkdrivingschool');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');

function wa_link(string $msg = SITE_WHATSAPP_MSG): string {
    return 'https://wa.me/' . SITE_WHATSAPP . '?text=' . rawurlencode($msg);
}

const NAV = [
    ['href' => '/',            'label' => 'Home'],
    ['href' => '/about',       'label' => 'About'],
    ['href' => '/courses',     'label' => 'Courses'],
    ['href' => '/why-us',      'label' => 'Why Us'],
    ['href' => '/gallery',     'label' => 'Gallery'],
    ['href' => '/blog',        'label' => 'Blog'],
    ['href' => '/contact',     'label' => 'Contact'],
];
