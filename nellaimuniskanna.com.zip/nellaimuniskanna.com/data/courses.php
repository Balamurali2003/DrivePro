<?php
declare(strict_types=1);

const COURSES = [
    [
        'name'      => 'Beginner Course',
        'duration'  => '21 Days',
        'sessions'  => '22 Practical Classes',
        'highlight' => false,
        'badge'     => null,
        'features'  => [
            'Vehicle controls & basics',
            'Steering, gears, clutch mastery',
            'Slow-speed maneuvering',
            'Traffic signal training',
            'LL + DL assistance',
        ],
    ],
    [
        'name'      => 'Ladies Special',
        'duration'  => '21 Days',
        'sessions'  => 'Female-friendly batches',
        'highlight' => true,
        'badge'     => 'Most loved',
        'features'  => [
            'Comfortable, judgement-free',
            'Patient female-aware coaching',
            'Flexible morning/evening',
            'Confidence-first approach',
            'Full license assistance',
        ],
    ],
    [
        'name'      => 'Advanced Driving',
        'duration'  => '10 Days',
        'sessions'  => 'Highway + city',
        'highlight' => false,
        'badge'     => null,
        'features'  => [
            'Highway & long-route practice',
            'Night driving sessions',
            'Defensive driving techniques',
            'Parking & reverse mastery',
            'Heavy traffic handling',
        ],
    ],
    [
        'name'      => 'Refresher Course',
        'duration'  => '7 Days',
        'sessions'  => 'For licensed drivers',
        'highlight' => false,
        'badge'     => null,
        'features'  => [
            'Brush-up after a long break',
            'Confidence rebuilding',
            'Modern car familiarization',
            'Personalized weak-area focus',
        ],
    ],
    [
        'name'      => 'License Assistance',
        'duration'  => 'End-to-end',
        'sessions'  => 'Documentation + Test',
        'highlight' => false,
        'badge'     => null,
        'features'  => [
            'RTO documentation help',
            'LL slot booking',
            'Driving test prep',
            'Permanent DL follow-up',
        ],
    ],
];
