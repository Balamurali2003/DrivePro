<?php
declare(strict_types=1);

const FAQS = [
    [
        'q' => 'How many classes are included?',
        'a' => 'Our standard course includes 22 practical driving classes. Each session is around 40–45 minutes of focused, real-road training.',
    ],
    [
        'q' => 'Do you provide license assistance?',
        'a' => "Yes — end-to-end. We help with Learner's License (LL), document verification, slot booking, mock RTO tests, and follow-up till your Permanent Driving License is delivered.",
    ],
    [
        'q' => 'Is ladies special coaching available?',
        'a' => 'Absolutely. We run a dedicated Ladies Special program with female-aware, judgement-free coaching. Many women have built confidence with us from absolute zero.',
    ],
    [
        'q' => 'Are flexible timings available?',
        'a' => 'Yes. We run batches from 6:00 AM to 8:00 PM on weekdays and Sunday mornings. Pick a slot that suits your work or college schedule.',
    ],
    [
        'q' => 'Which areas do you serve?',
        'a' => 'We are based at Tirunelveli Junction and serve all surrounding localities including Palayamkottai, Vannarpettai, Melapalayam, Perumalpuram and nearby towns.',
    ],
    [
        'q' => 'Do you teach in Tamil and English?',
        'a' => 'Yes — our trainers explain concepts comfortably in Tamil, English, or a mix, based on what you prefer.',
    ],
    [
        'q' => 'Can I take a free demo first?',
        'a' => 'Of course! Book a free demo class and meet your trainer before committing. WhatsApp us anytime to schedule.',
    ],
];
