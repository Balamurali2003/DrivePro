<?php
declare(strict_types=1);

const TESTIMONIALS = [
    [
        'name'   => 'Priya R.',
        'role'   => 'First-time driver, Tirunelveli',
        'quote'  => 'I was terrified of driving. Muthukumar sir was so patient — within 3 weeks I was driving on Tirunelveli main roads confidently. Got my license first attempt!',
        'rating' => 5,
    ],
    [
        'name'   => 'Karthik S.',
        'role'   => 'Working professional',
        'quote'  => "Best driving school in town. The trainers don't just rush you through — they actually teach you to drive safely. Worth every rupee.",
        'rating' => 5,
    ],
    [
        'name'   => 'Meena V.',
        'role'   => 'Homemaker',
        'quote'  => 'The ladies special batch made me so comfortable. I never felt judged for slow learning. Highly recommend for women.',
        'rating' => 5,
    ],
    [
        'name'   => 'Arun K.',
        'role'   => 'College student',
        'quote'  => 'Flexible timings helped me fit classes between college. Real road practice on Junction roads was super useful.',
        'rating' => 5,
    ],
    [
        'name'   => 'Lakshmi P.',
        'role'   => 'Refresher learner',
        'quote'  => "Hadn't driven in 8 years. The refresher course rebuilt my confidence completely. Sir is gold.",
        'rating' => 5,
    ],
    [
        'name'   => 'Vignesh M.',
        'role'   => 'Software engineer',
        'quote'  => 'Highway training was the highlight. Got proper exposure to real conditions, not just empty grounds. Thank you team!',
        'rating' => 5,
    ],
];
