<?php
declare(strict_types=1);

const STATIC_POSTS = [];
