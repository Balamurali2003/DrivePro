<?php
$meta = [
    'title'       => 'Student Testimonials — Sri Munis Kanna Driving School',
    'description' => 'Read success stories from 500+ learners who got their driving license with Sri Munis Kanna Driving School in Tirunelveli.',
    'canonical'   => '/testimonials',
];
$eyebrow  = 'Success stories';
$title    = 'What our learners say.';
$subtitle = '500+ confident drivers trained across Tirunelveli.';
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>
<?php include __DIR__ . '/../includes/sections/testimonials.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
