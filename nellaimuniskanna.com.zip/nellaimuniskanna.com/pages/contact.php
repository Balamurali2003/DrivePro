<?php
$meta = [
    'title'       => 'Contact Us — Sri Munis Kanna Driving School Tirunelveli',
    'description' => 'Call, WhatsApp or visit Sri Munis Kanna Driving School at Tirunelveli Junction. Enquire about courses, timings and free demo classes.',
    'canonical'   => '/contact',
];
$eyebrow  = 'Contact us';
$title    = 'We\'d love to hear from you.';
$subtitle = 'Call, WhatsApp or send us a message — we respond within minutes.';
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-form.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
