<?php
declare(strict_types=1);

require_admin_login();

$errors = [];
$data   = [
    'title'           => '',
    'slug'            => '',
    'excerpt'         => '',
    'image_url'       => '',
    'read_time'       => '',
    'tags'            => '',
    'content'         => '',
    'seo_title'       => '',
    'seo_description' => '',
    'published'       => false,
    'published_at'    => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $data['title']           = trim($_POST['title'] ?? '');
    $data['slug']            = trim($_POST['slug'] ?? '');
    $data['excerpt']         = trim($_POST['excerpt'] ?? '');
    $data['image_url']       = trim($_POST['image_url'] ?? '');
    $data['read_time']       = trim($_POST['read_time'] ?? '');
    $data['tags']            = trim($_POST['tags'] ?? '');
    $data['content']         = trim($_POST['content'] ?? '');
    $data['seo_title']       = trim($_POST['seo_title'] ?? '');
    $data['seo_description'] = trim($_POST['seo_description'] ?? '');
    $data['published']       = !empty($_POST['published']);
    $data['published_at']    = trim($_POST['published_at'] ?? '');

    $image_action = $_POST['image_action'] ?? 'keep';
    if ($image_action === 'replace' && !empty($_FILES['image_file']['name'])) {
        try {
            $data['image_url'] = handle_image_upload($_FILES['image_file']);
        } catch (\RuntimeException $e) {
            $errors[] = 'Image upload failed: ' . $e->getMessage();
        }
    } elseif ($image_action === 'clear') {
        $data['image_url'] = '';
    }

    if ($data['title'] === '') $errors[] = 'Title is required.';
    if ($data['slug'] === '')  $data['slug'] = slugify($data['title']);

    if (empty($errors)) {
        $tags = array_values(array_filter(array_map('trim', explode(',', $data['tags']))));
        try {
            create_post([
                'title'           => $data['title'],
                'slug'            => $data['slug'],
                'excerpt'         => $data['excerpt'],
                'image_url'       => $data['image_url'],
                'read_time'       => $data['read_time'],
                'tags'            => $tags,
                'content'         => $data['content'],
                'seo_title'       => $data['seo_title'],
                'seo_description' => $data['seo_description'],
                'published'       => $data['published'],
                'published_at'    => $data['published_at']
                    ? date('Y-m-d H:i:s', strtotime($data['published_at']))
                    : '',
            ]);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Post created successfully.'];
            header('Location: /admin/posts');
            exit;
        } catch (\Exception $e) {
            $errors[] = 'Failed to save post. ' . $e->getMessage();
        }
    }
}

$admin_title = 'New Post';

ob_start();
?>
<?php if ($errors): ?>
<div class="alert alert-error" style="max-width:760px">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
  <div class="alert-body">
    <div class="alert-title">Please fix the following</div>
    <?php foreach ($errors as $e): ?><div><?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<form method="POST" action="/admin/posts/create" enctype="multipart/form-data"
      style="max-width:760px;display:flex;flex-direction:column;gap:0">
  <?= csrf_field() ?>
  <?php include __DIR__ . '/../../includes/admin-post-form.php'; ?>
  <div class="form-actions" style="margin-top:24px;padding-top:20px;border-top:1px solid var(--bdr)">
    <button type="submit" class="btn btn-primary">Save Post</button>
    <a href="/admin/posts" class="btn btn-ghost">Cancel</a>
  </div>
</form>
<?php
$admin_content = ob_get_clean();
include __DIR__ . '/../../includes/admin-layout.php';
