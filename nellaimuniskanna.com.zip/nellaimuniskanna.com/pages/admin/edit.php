<?php
declare(strict_types=1);

require_admin_login();

$id   = (int) ($route_params['id'] ?? 0);
$post = $id > 0 ? get_post_by_id($id) : null;

if (!$post) {
    http_response_code(404);
    echo '<!DOCTYPE html><html><body style="font-family:sans-serif;padding:2rem"><h2>Post not found</h2><a href="/admin/posts">Back to posts</a></body></html>';
    exit;
}

$errors = [];
$data   = [
    'title'           => $post['title'],
    'slug'            => $post['slug'],
    'excerpt'         => $post['excerpt'] ?? '',
    'image_url'       => $post['image_url'] ?? '',
    'read_time'       => $post['read_time'] ?? '',
    'tags'            => implode(', ', $post['tags'] ?? []),
    'content'         => $post['content'] ?? '',
    'seo_title'       => $post['seo_title'] ?? '',
    'seo_description' => $post['seo_description'] ?? '',
    'published'       => (bool) $post['published'],
    'published_at'    => $post['published_at'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $data['title']           = trim($_POST['title'] ?? '');
    $data['slug']            = trim($_POST['slug'] ?? '');
    $data['excerpt']         = trim($_POST['excerpt'] ?? '');
    $data['image_url']       = $post['image_url'] ?? '';
    $data['read_time']       = trim($_POST['read_time'] ?? '');
    $data['tags']            = trim($_POST['tags'] ?? '');
    $data['content']         = trim($_POST['content'] ?? '');
    $data['seo_title']       = trim($_POST['seo_title'] ?? '');
    $data['seo_description'] = trim($_POST['seo_description'] ?? '');
    $data['published']       = !empty($_POST['published']);
    $data['published_at']    = trim($_POST['published_at'] ?? '');

    $image_action = $_POST['image_action'] ?? 'keep';
    if ($image_action === 'replace' && !empty($_FILES['image_file']['name'])) {
        try {
            $data['image_url'] = handle_image_upload($_FILES['image_file'], $post['image_url'] ?? '');
        } catch (\RuntimeException $e) {
            $errors[] = 'Image upload failed: ' . $e->getMessage();
        }
    } elseif ($image_action === 'clear') {
        delete_uploaded_image($post['image_url'] ?? '');
        $data['image_url'] = '';
    }

    if ($data['title'] === '') $errors[] = 'Title is required.';
    if ($data['slug'] === '')  $data['slug'] = slugify($data['title']);

    if (empty($errors)) {
        $tags = array_values(array_filter(array_map('trim', explode(',', $data['tags']))));
        try {
            update_post($id, [
                'title'           => $data['title'],
                'slug'            => $data['slug'],
                'excerpt'         => $data['excerpt'],
                'image_url'       => $data['image_url'],
                'read_time'       => $data['read_time'],
                'tags'            => $tags,
                'content'         => $data['content'],
                'seo_title'       => $data['seo_title'],
                'seo_description' => $data['seo_description'],
                'published'       => $data['published'],
                'published_at'    => $data['published_at']
                    ? date('Y-m-d H:i:s', strtotime($data['published_at']))
                    : '',
            ]);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Post updated successfully.'];
            header('Location: /admin/posts');
            exit;
        } catch (\Exception $e) {
            $errors[] = 'Failed to update post. ' . $e->getMessage();
        }
    }
}

$admin_title = 'Edit: ' . $post['title'];

ob_start();
?>
<?php if ($errors): ?>
<div class="alert alert-error" style="max-width:760px">
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
  <div class="alert-body">
    <div class="alert-title">Please fix the following</div>
    <?php foreach ($errors as $e): ?><div><?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- Post stats bar -->
<div style="max-width:760px;display:flex;align-items:center;gap:20px;padding:12px 16px;background:#fff;border:1px solid var(--bdr);border-radius:10px;margin-bottom:22px;font-size:12.5px;color:var(--muted)">
  <span style="display:flex;align-items:center;gap:5px">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
    <strong style="color:var(--text)"><?= number_format($post['views']) ?></strong> reads
  </span>
  <?php if ($post['read_time']): ?>
  <span style="display:flex;align-items:center;gap:5px">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
    <?= htmlspecialchars($post['read_time']) ?>
  </span>
  <?php endif; ?>
  <?php if ($post['published_at']): ?>
  <span>Published <?= date('d M Y', strtotime($post['published_at'])) ?></span>
  <?php endif; ?>
  <?php if (post_status($post) === 'published'): ?>
  <a href="/blog/<?= htmlspecialchars($post['slug']) ?>" target="_blank"
     style="margin-left:auto;font-size:12px;color:var(--accent-hover);text-decoration:none;display:flex;align-items:center;gap:4px">
    View live
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
  </a>
  <?php endif; ?>
</div>

<form method="POST" action="/admin/posts/edit/<?= $id ?>" enctype="multipart/form-data"
      style="max-width:760px;display:flex;flex-direction:column;gap:0">
  <?= csrf_field() ?>
  <?php include __DIR__ . '/../../includes/admin-post-form.php'; ?>
  <div class="form-actions" style="margin-top:24px;padding-top:20px;border-top:1px solid var(--bdr)">
    <button type="submit" class="btn btn-primary">Update Post</button>
    <a href="/admin/posts" class="btn btn-ghost">Cancel</a>
  </div>
</form>
<?php
$admin_content = ob_get_clean();
include __DIR__ . '/../../includes/admin-layout.php';
