<?php
declare(strict_types=1);

require_admin_login();

$per_page     = 25;
$current_page = max(1, (int) ($_GET['page'] ?? 1));
$offset       = ($current_page - 1) * $per_page;

$total      = count_enquiries();
$unread     = count_enquiries(true);
$enquiries  = get_enquiries($per_page, $offset);

$admin_title = 'Enquiries';
$admin_flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

ob_start();
?>
<!-- Stats -->
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:24px;max-width:480px">
  <?php
  $stats = [
    ['label' => 'Total',  'value' => $total,          'color' => '#18181B'],
    ['label' => 'Unread', 'value' => $unread,          'color' => '#B91C1C'],
    ['label' => 'Read',   'value' => $total - $unread, 'color' => '#15803D'],
  ];
  foreach ($stats as $s): ?>
  <div class="card" style="padding:18px 20px">
    <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:6px"><?= $s['label'] ?></div>
    <div style="font-size:26px;font-weight:700;color:<?= $s['color'] ?>;letter-spacing:-.02em"><?= $s['value'] ?></div>
  </div>
  <?php endforeach; ?>
</div>

<?php if (empty($enquiries)): ?>
<div class="card">
  <div class="empty-state">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
    <h3>No enquiries yet</h3>
    <p>Submissions from your contact and booking forms will appear here.</p>
  </div>
</div>
<?php else: ?>
<div class="card" style="overflow:hidden">
  <table class="adm-table">
    <thead>
      <tr>
        <th>Name / Phone</th>
        <th>Course / Message</th>
        <th>Source</th>
        <th>Date</th>
        <th>Status</th>
        <th class="col-actions">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($enquiries as $q):
        $is_unread = !(bool) $q['is_read'];
      ?>
      <tr style="<?= $is_unread ? 'background:#FFFBEB' : '' ?>">
        <td>
          <div style="font-weight:600;color:var(--text);font-size:13.5px"><?= htmlspecialchars($q['name']) ?></div>
          <a href="tel:<?= htmlspecialchars($q['phone']) ?>"
             style="font-size:12px;color:var(--muted);text-decoration:none"><?= htmlspecialchars($q['phone']) ?></a>
        </td>
        <td style="max-width:280px">
          <?php if (!empty($q['course'])): ?>
          <div style="font-size:13px;font-weight:500;color:var(--text)"><?= htmlspecialchars($q['course']) ?></div>
          <?php endif; ?>
          <?php if (!empty($q['message'])): ?>
          <div style="font-size:12px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:260px"
               title="<?= htmlspecialchars($q['message']) ?>">
            <?= htmlspecialchars(mb_strimwidth($q['message'], 0, 100, '…')) ?>
          </div>
          <?php endif; ?>
          <?php if (!empty($q['preferred_date'])): ?>
          <div style="font-size:11.5px;color:var(--xs-muted);margin-top:2px">
            Demo: <?= date('d M Y', strtotime($q['preferred_date'])) ?>
          </div>
          <?php endif; ?>
        </td>
        <td>
          <?php if ($q['source'] === 'book-demo'): ?>
          <span class="badge" style="background:#EFF6FF;color:#1D4ED8">Book Demo</span>
          <?php else: ?>
          <span class="badge" style="background:#F4F4F5;color:#52525B">Contact</span>
          <?php endif; ?>
        </td>
        <td class="col-date"><?= date('d M Y, H:i', strtotime($q['created_at'])) ?></td>
        <td>
          <?php if ($is_unread): ?>
          <span class="badge" style="background:#FEF2F2;color:#B91C1C">
            <span class="badge-dot" style="background:#EF4444"></span>New
          </span>
          <?php else: ?>
          <span class="badge" style="background:#F4F4F5;color:#71717A">Read</span>
          <?php endif; ?>
        </td>
        <td class="col-actions">
          <div style="display:flex;align-items:center;justify-content:flex-end;gap:12px">
            <?php if ($is_unread): ?>
            <form method="POST" action="/admin/enquiries/read/<?= $q['id'] ?>">
              <?= csrf_field() ?>
              <button type="submit" class="btn-link">Mark read</button>
            </form>
            <?php endif; ?>
            <form method="POST" action="/admin/enquiries/delete/<?= $q['id'] ?>"
                  onsubmit="return confirm('Delete this enquiry from <?= htmlspecialchars(addslashes($q['name'])) ?>?')">
              <?= csrf_field() ?>
              <button type="submit" class="btn-danger-ghost">Delete</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if ($total > $per_page): ?>
<div style="margin-top:16px">
  <?= pagination_html($total, $per_page, $current_page, '/admin/enquiries') ?>
</div>
<?php endif; ?>
<?php endif; ?>
<?php
$admin_content = ob_get_clean();
include __DIR__ . '/../../includes/admin-layout.php';
