<?php
declare(strict_types=1);

if (is_admin_logged_in()) {
    header('Location: /admin/posts');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (admin_login($username, $password)) {
        header('Location: /admin/posts');
        exit;
    }

    $error = 'Incorrect username or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign in — SMK Admin</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', system-ui, sans-serif;
      background: #F4F4F5;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      -webkit-font-smoothing: antialiased;
    }
    .login-wrap { width: 100%; max-width: 360px; padding: 16px; }

    .login-logo {
      display: flex; flex-direction: column; align-items: center; gap: 8px;
      margin-bottom: 28px;
    }
    .login-logo-icon {
      width: 44px; height: 44px;
      background: #111;
      border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
    }
    .login-logo-name { font-size: 17px; font-weight: 700; color: #18181B; letter-spacing: -.02em; }
    .login-logo-sub  { font-size: 13px; color: #71717A; }

    .login-card {
      background: #fff;
      border: 1px solid #E4E4E7;
      border-radius: 16px;
      padding: 28px 28px 24px;
      box-shadow: 0 1px 4px rgba(0,0,0,.07), 0 1px 2px rgba(0,0,0,.04);
    }

    .alert-error {
      display: flex; align-items: center; gap: 8px;
      background: #FEF2F2;
      border: 1px solid #FECACA;
      color: #B91C1C;
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 13px;
      font-weight: 500;
      margin-bottom: 18px;
    }

    .form-group  { display: flex; flex-direction: column; gap: 5px; margin-bottom: 14px; }
    .form-label  { font-size: 13px; font-weight: 500; color: #18181B; }
    .form-input  {
      width: 100%;
      background: #fff;
      border: 1px solid #D4D4D8;
      border-radius: 8px;
      padding: 9px 13px;
      font-family: inherit;
      font-size: 14px;
      color: #18181B;
      outline: none;
      transition: border-color .15s, box-shadow .15s;
      -webkit-appearance: none;
    }
    .form-input:focus {
      border-color: #F59E0B;
      box-shadow: 0 0 0 3px rgba(245,158,11,.14);
    }
    .form-input::placeholder { color: #A1A1AA; }

    .btn-submit {
      width: 100%;
      margin-top: 6px;
      background: #F59E0B;
      color: #111;
      border: none;
      border-radius: 8px;
      padding: 10px;
      font-family: inherit;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: background .15s;
    }
    .btn-submit:hover  { background: #D97706; }
    .btn-submit:active { opacity: .85; }

    .login-footer {
      text-align: center;
      margin-top: 20px;
      font-size: 12px;
      color: #A1A1AA;
    }
    .login-footer a { color: #71717A; text-decoration: none; }
    .login-footer a:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="login-wrap">
    <div class="login-logo">
      <div class="login-logo-icon">
        <svg width="20" height="20" viewBox="0 0 16 16" fill="none"><path d="M3 12L8 4l5 8H3z" fill="#F59E0B"/></svg>
      </div>
      <div class="login-logo-name">SMK Admin</div>
      <div class="login-logo-sub">Sri Munis Kanna Driving School</div>
    </div>

    <div class="login-card">
      <?php if ($error): ?>
      <div class="alert-error">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <?= htmlspecialchars($error) ?>
      </div>
      <?php endif; ?>

      <form method="POST" action="/admin/login" autocomplete="on">
        <div class="form-group">
          <label class="form-label" for="username">Username</label>
          <input
            class="form-input"
            type="text"
            id="username"
            name="username"
            required
            autocomplete="username"
            spellcheck="false"
            value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
          >
        </div>
        <div class="form-group" style="margin-bottom:20px">
          <label class="form-label" for="password">Password</label>
          <input
            class="form-input"
            type="password"
            id="password"
            name="password"
            required
            autocomplete="current-password"
          >
        </div>
        <button type="submit" class="btn-submit">Sign in</button>
      </form>
    </div>

    <div class="login-footer">
      <a href="/" target="_blank">View public site &rarr;</a>
    </div>
  </div>
</body>
</html>
