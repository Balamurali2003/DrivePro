<?php
declare(strict_types=1);

require_admin_login();

$per_page     = 12;
$current_page = max(1, (int) ($_GET['page'] ?? 1));
$offset       = ($current_page - 1) * $per_page;

$all_posts    = get_all_posts_admin();
$posts        = get_all_posts_admin($per_page, $offset);
$admin_title  = 'Blog Posts';
$admin_action = ['href' => '/admin/posts/create', 'label' => '+ New Post'];
$admin_flash  = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Stats from full dataset
$total       = count($all_posts);
$published   = count(array_filter($all_posts, fn($p) => $p['status'] === 'published'));
$scheduled   = count(array_filter($all_posts, fn($p) => $p['status'] === 'scheduled'));
$drafts      = count(array_filter($all_posts, fn($p) => $p['status'] === 'draft'));
$total_views = array_sum(array_column($all_posts, 'views'));

ob_start();
?>
<!-- Stats row -->
<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:24px">
  <?php
  $stats = [
    ['label' => 'Total Posts',   'value' => $total,       'color' => '#18181B'],
    ['label' => 'Published',     'value' => $published,   'color' => '#15803D'],
    ['label' => 'Scheduled',     'value' => $scheduled,   'color' => '#1D4ED8'],
    ['label' => 'Total Reads',   'value' => number_format($total_views), 'color' => '#B45309'],
  ];
  foreach ($stats as $s):
  ?>
  <div class="card" style="padding:18px 20px">
    <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:6px"><?= $s['label'] ?></div>
    <div style="font-size:26px;font-weight:700;color:<?= $s['color'] ?>;letter-spacing:-.02em"><?= $s['value'] ?></div>
  </div>
  <?php endforeach; ?>
</div>

<?php if (empty($posts)): ?>
<div class="card">
  <div class="empty-state">
    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
    <h3>No posts yet</h3>
    <p>Create your first blog post to get started.</p>
  </div>
</div>
<?php else: ?>

<!-- Card grid — mirrors public blog layout -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px">
  <?php foreach ($posts as $post):
    $tag     = $post['tags'][0] ?? 'Blog';
    $status  = $post['status'];
    $date    = $post['published_at']
               ? date('d M Y', strtotime($post['published_at']))
               : date('d M Y', strtotime($post['created_at']));
  ?>
  <div style="background:#fff;border:1px solid var(--bdr);border-radius:16px;overflow:hidden;box-shadow:var(--shadow);display:flex;flex-direction:column">

    <!-- Card thumbnail -->
    <div style="aspect-ratio:16/10;background:linear-gradient(135deg,#111 0%,#1f1f1f 50%,#111 100%);position:relative;overflow:hidden">
      <?php if (!empty($post['image_url'])): ?>
      <img src="<?= htmlspecialchars($post['image_url']) ?>" alt=""
           style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.9">
      <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,.5) 0%,transparent 55%)"></div>
      <?php else: ?>
      <div style="position:absolute;inset:0;background:repeating-linear-gradient(45deg,transparent,transparent 10px,rgba(245,158,11,.06) 10px,rgba(245,158,11,.06) 20px)"></div>
      <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;color:#F59E0B;opacity:.25;font-family:'Inter',sans-serif;letter-spacing:-.02em;user-select:none">
        <?= htmlspecialchars($tag) ?>
      </div>
      <?php endif; ?>
      <!-- Tag pill -->
      <span style="position:absolute;top:12px;left:12px;background:#F59E0B;color:#111;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;padding:3px 10px;border-radius:99px">
        <?= htmlspecialchars($tag) ?>
      </span>
      <!-- Status badge -->
      <?php if ($status === 'scheduled'): ?>
      <span style="position:absolute;top:12px;right:12px;background:#1D4ED8;color:#fff;font-size:10px;font-weight:600;padding:3px 9px;border-radius:99px;letter-spacing:.04em">
        Scheduled
      </span>
      <?php elseif ($status === 'draft'): ?>
      <span style="position:absolute;top:12px;right:12px;background:rgba(0,0,0,.6);color:rgba(255,255,255,.7);font-size:10px;font-weight:600;padding:3px 9px;border-radius:99px;letter-spacing:.04em">
        Draft
      </span>
      <?php endif; ?>
    </div>

    <!-- Card body -->
    <div style="padding:16px 18px 14px;flex:1;display:flex;flex-direction:column">
      <h3 style="font-size:15px;font-weight:600;color:#18181B;line-height:1.35;margin-bottom:6px">
        <?= htmlspecialchars($post['title']) ?>
      </h3>
      <?php if ($post['excerpt']): ?>
      <p style="font-size:13px;color:#71717A;line-height:1.5;margin-bottom:12px;flex:1">
        <?= htmlspecialchars(mb_strimwidth($post['excerpt'], 0, 110, '…')) ?>
      </p>
      <?php else: ?>
      <div style="flex:1"></div>
      <?php endif; ?>

      <!-- Meta row: read time + views + date -->
      <div style="display:flex;align-items:center;gap:12px;font-size:11.5px;color:#A1A1AA;margin-bottom:14px;padding-top:10px;border-top:1px solid var(--bdr)">
        <?php if ($post['read_time']): ?>
        <span style="display:flex;align-items:center;gap:4px">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          <?= htmlspecialchars($post['read_time']) ?>
        </span>
        <?php endif; ?>
        <span style="display:flex;align-items:center;gap:4px">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          <?= number_format($post['views']) ?> reads
        </span>
        <span style="margin-left:auto"><?= $date ?></span>
      </div>

      <!-- Actions -->
      <div style="display:flex;align-items:center;gap:10px">
        <a href="/admin/posts/edit/<?= $post['id'] ?>" class="btn btn-primary btn-sm" style="flex:1;justify-content:center">Edit</a>
        <form method="POST" action="/admin/posts/delete/<?= $post['id'] ?>"
              onsubmit="return confirm('Delete \'<?= htmlspecialchars(addslashes($post['title'])) ?>\'?\nThis cannot be undone.')">
          <?= csrf_field() ?>
          <button type="submit" class="btn btn-ghost btn-sm" style="color:#DC2626;border-color:#FECACA">Delete</button>
        </form>
        <?php if ($status === 'published'): ?>
        <a href="/blog/<?= htmlspecialchars($post['slug']) ?>" target="_blank" class="btn btn-ghost btn-sm" title="View on site" style="padding:5px 8px">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div style="margin-top:18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
  <p style="font-size:12px;color:#A1A1AA">
    <?= $total ?> post<?= $total !== 1 ? 's' : '' ?> &middot;
    <?= $published ?> published &middot;
    <?= $scheduled ?> scheduled &middot;
    <?= $drafts ?> draft<?= $drafts !== 1 ? 's' : '' ?>
  </p>
  <?php if ($total > $per_page): ?>
  <?= pagination_html($total, $per_page, $current_page, '/admin/posts') ?>
  <?php endif; ?>
</div>
<?php endif; ?>
<?php
$admin_content = ob_get_clean();
include __DIR__ . '/../../includes/admin-layout.php';
