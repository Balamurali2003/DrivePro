<?php
$meta = [
    'title'          => 'About Us — Sri Munis Kanna Driving School Tirunelveli',
    'description'    => "Founded by M. Muthukumar, we've trained 500+ confident drivers in Tirunelveli with patient, real-road coaching.",
    'og_title'       => 'About — Sri Munis Kanna Driving School',
    'og_description' => "Tirunelveli's trusted driving academy with 15+ years of experience.",
    'canonical'      => '/about',
];
$eyebrow  = 'About us';
$title    = 'A driving school built on patience, safety and real roads.';
$subtitle = "We've spent over 15 years turning nervous beginners into confident drivers across Tirunelveli.";
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>
<?php include __DIR__ . '/../includes/sections/about.php'; ?>
<?php include __DIR__ . '/../includes/sections/owner.php'; ?>
<?php include __DIR__ . '/../includes/sections/trust-indicators.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
