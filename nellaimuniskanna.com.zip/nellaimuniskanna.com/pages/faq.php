<?php
$meta = [
    'title'       => 'FAQ — Sri Munis Kanna Driving School Tirunelveli',
    'description' => 'Answers to common questions about courses, timings, license process, ladies coaching and more.',
    'canonical'   => '/faq',
];
$eyebrow  = 'FAQ';
$title    = 'Everything you need to know.';
$subtitle = 'Quick answers to our most common questions.';
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>
<?php include __DIR__ . '/../includes/sections/faq-section.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
