<?php
$per_page = 9;
$page     = max(1, (int) ($_GET['page'] ?? 1));
$search   = trim($_GET['search'] ?? '');
$offset   = ($page - 1) * $per_page;

$total = count_blog_posts($search);
$posts = get_blog_posts($per_page, $offset, true, $search);

$meta = [
    'title'       => ($search ? 'Search: ' . $search . ' — ' : '') . 'Driving Tips & Blog — ' . SITE_NAME,
    'description' => "Beginner driving tips, traffic rules, parking guides, night driving and highway safety from Tirunelveli's premium driving academy.",
    'canonical'   => '/blog',
];

$eyebrow = 'Blog & driving tips';
$title   = 'Practical guides to drive smarter.';
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>

<section class="py-16 md:py-24 bg-background">
  <div class="mx-auto max-w-7xl px-4">

    <!-- Search bar -->
    <form method="GET" action="/blog" class="mb-10 max-w-2xl mx-auto">
      <div class="flex gap-2 p-1.5 rounded-2xl border border-border bg-card shadow-card">
        <div class="relative flex-1">
          <span class="absolute inset-y-0 left-3.5 flex items-center pointer-events-none text-muted-foreground">
            <?= icon('search', 'size-4') ?>
          </span>
          <input
            type="search"
            name="search"
            value="<?= htmlspecialchars($search) ?>"
            placeholder="Search articles…"
            class="w-full h-10 pl-10 pr-3 bg-transparent text-sm text-ink placeholder:text-muted-foreground focus:outline-none"
          >
        </div>
        <?php if ($search): ?>
        <a href="/blog"
           class="flex items-center px-3 h-10 rounded-xl text-sm font-medium text-muted-foreground hover:text-ink transition-colors">
          Clear
        </a>
        <?php endif; ?>
        <button type="submit"
          class="h-10 px-5 rounded-xl bg-gradient-yellow text-ink text-sm font-semibold hover:opacity-90 transition-opacity shadow-glow">
          Search
        </button>
      </div>
    </form>

    <!-- Results count -->
    <?php if ($search): ?>
    <p class="text-sm text-muted-foreground mb-8 text-center">
      <?= $total ?> result<?= $total !== 1 ? 's' : '' ?> for
      <strong class="text-ink">&ldquo;<?= htmlspecialchars($search) ?>&rdquo;</strong>
    </p>
    <?php endif; ?>

    <?php if (empty($posts)): ?>
    <!-- Empty state -->
    <div class="py-24 text-center text-muted-foreground">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="mx-auto mb-4 opacity-30"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <p class="font-medium text-ink mb-1">No articles found</p>
      <p class="text-sm">Try a different search term.</p>
    </div>

    <?php else: ?>
    <!-- Post grid -->
    <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <?php foreach ($posts as $p):
        $tag = $p['tags'][0] ?? 'Blog';
      ?>
      <a href="/blog/<?= htmlspecialchars($p['slug']) ?>"
         class="reveal group rounded-3xl overflow-hidden bg-card border border-border shadow-card hover:shadow-glow transition-all duration-500 hover:-translate-y-1 block no-underline">

        <!-- Thumbnail: real image or gradient fallback -->
        <div class="aspect-[16/10] relative overflow-hidden bg-ink">
          <?php if (!empty($p['image_url'])): ?>
          <img src="<?= htmlspecialchars($p['image_url']) ?>"
               alt="<?= htmlspecialchars($p['title']) ?>"
               class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105">
          <div class="absolute inset-0" style="background:linear-gradient(to top, rgba(0,0,0,.45) 0%, transparent 60%)"></div>
          <span class="absolute top-4 left-4 text-[10px] uppercase tracking-widest bg-yellow text-ink font-semibold px-3 py-1 rounded-full">
            <?= htmlspecialchars($tag) ?>
          </span>
          <?php else: ?>
          <div class="absolute inset-0 bg-gradient-to-br from-ink via-ink-soft to-ink">
            <div class="absolute inset-0 stripe-yellow" style="opacity:0.08"></div>
            <div class="absolute inset-0 flex items-center justify-center text-yellow font-display font-bold text-4xl group-hover:opacity-100 transition-opacity" style="opacity:.25">
              <?= htmlspecialchars($tag) ?>
            </div>
          </div>
          <span class="absolute top-4 left-4 text-[10px] uppercase tracking-widest bg-yellow text-ink font-semibold px-3 py-1 rounded-full">
            <?= htmlspecialchars($tag) ?>
          </span>
          <?php endif; ?>
        </div>

        <!-- Card body -->
        <div class="p-6">
          <h3 class="font-display font-bold text-xl text-ink leading-tight group-hover:text-yellow-deep transition-colors">
            <?= htmlspecialchars($p['title']) ?>
          </h3>
          <p class="mt-2 text-sm text-muted-foreground leading-relaxed">
            <?= htmlspecialchars($p['excerpt']) ?>
          </p>
          <div class="mt-5 text-xs text-muted-foreground flex items-center justify-between">
            <span><?= htmlspecialchars($p['read'] ?: $p['publishedAt']) ?></span>
            <?= icon('arrow-up-right', 'size-4 text-yellow-deep') ?>
          </div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total > $per_page): ?>
    <div class="mt-14">
      <?php
        $base = '/blog' . ($search ? '?search=' . urlencode($search) . '&' : '?');
        // strip trailing '?'
        $base = rtrim($base, '?');
        echo pagination_html($total, $per_page, $page, $base);
      ?>
    </div>
    <?php endif; ?>

    <!-- Post count -->
    <p class="mt-6 text-xs text-muted-foreground text-center">
      Showing <?= count($posts) ?> of <?= $total ?> article<?= $total !== 1 ? 's' : '' ?>
    </p>
    <?php endif; ?>

  </div>
</section>

<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
