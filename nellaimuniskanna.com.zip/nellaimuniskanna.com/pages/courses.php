<?php
require_once __DIR__ . '/../data/courses.php';

$meta = [
    'title'          => 'Driving Courses & Packages — Sri Munis Kanna Driving School',
    'description'    => 'Beginner, advanced, ladies special, refresher and license assistance courses in Tirunelveli. Pick a package that fits your goals.',
    'og_title'       => 'Courses — Sri Munis Kanna Driving School',
    'og_description' => 'Beginner to advanced driving courses with full license assistance.',
    'canonical'      => '/courses',
];
$eyebrow  = 'Courses & packages';
$title    = 'Programs designed for every kind of driver.';
$subtitle = "Whether you're starting from zero or polishing existing skills, there's a course built for you.";
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>

<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-7xl px-4 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
    <?php foreach (COURSES as $c):
      $hi = $c['highlight'];
    ?>
      <div class="reveal relative rounded-3xl p-7 border transition-all duration-500 hover:-translate-y-1 <?= $hi ? 'bg-ink text-white border-yellow shadow-glow' : 'bg-card text-ink border-border shadow-card hover:shadow-glow' ?>">
        <?php if ($c['badge']): ?>
          <span class="absolute -top-3 right-6 inline-flex items-center gap-1 rounded-full bg-gradient-yellow text-ink text-xs font-semibold px-3 py-1 shadow-glow">
            <?= icon('sparkles', 'size-3') ?> <?= htmlspecialchars($c['badge']) ?>
          </span>
        <?php endif; ?>
        <div class="flex items-start justify-between">
          <div>
            <h3 class="text-2xl font-display font-bold"><?= htmlspecialchars($c['name']) ?></h3>
            <p class="text-sm mt-1 <?= $hi ? 'text-yellow' : 'text-muted-foreground' ?>"><?= htmlspecialchars($c['sessions']) ?></p>
          </div>
          <span class="rounded-full px-3 py-1 text-xs font-medium <?= $hi ? 'bg-yellow text-ink' : 'bg-secondary text-ink' ?>">
            <?= htmlspecialchars($c['duration']) ?>
          </span>
        </div>
        <ul class="mt-6 space-y-3">
          <?php foreach ($c['features'] as $f): ?>
            <li class="flex gap-2 text-sm">
              <?= icon('check', 'size-4 mt-0.5 shrink-0 ' . ($hi ? 'text-yellow' : 'text-yellow-deep')) ?>
              <span class="<?= $hi ? 'text-white/85' : 'text-ink' ?>"><?= htmlspecialchars($f) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
        <a href="/book-demo" class="block mt-7">
          <button class="w-full inline-flex items-center justify-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition-opacity <?= $hi ? 'bg-gradient-yellow text-ink' : 'bg-ink text-white' ?>">
            Enquire Now <?= icon('arrow-right', 'size-4') ?>
          </button>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<?php include __DIR__ . '/../includes/sections/license-process.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
