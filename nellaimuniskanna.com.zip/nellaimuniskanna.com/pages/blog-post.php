<?php
$post = get_post_by_slug($route_params['slug'] ?? '');

if (!$post) {
    http_response_code(404);
    $meta = ['title' => 'Post Not Found — ' . SITE_NAME];
    ob_start(); ?>
    <section style="min-height:55vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:4rem 1rem">
      <div>
        <p style="font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.15em;color:#D97706;margin-bottom:.75rem">404</p>
        <h1 style="font-size:1.75rem;font-weight:700;margin-bottom:.75rem">Post not found</h1>
        <p style="color:#6b7280;margin-bottom:2rem">This article may have been moved or unpublished.</p>
        <a href="/blog" style="display:inline-flex;align-items:center;gap:.4rem;background:#FBBF24;color:#111;font-weight:600;padding:.6rem 1.5rem;border-radius:.75rem;text-decoration:none;font-size:.9rem">
          &larr; Back to Blog
        </a>
      </div>
    </section>
    <?php $content = ob_get_clean();
    include __DIR__ . '/../includes/layout.php';
    exit;
}

record_post_view($post['id']);

$tag      = $post['tags'][0] ?? 'Blog';
$pub_date = $post['published_at'] ? date('d M Y', strtotime($post['published_at'])) : '';
$pub_iso  = $post['published_at'] ? date('c', strtotime($post['published_at'])) : '';
$og_image = $post['image_url'] ?: '/assets/og.jpg';
$post_url = SITE_URL . '/blog/' . $post['slug'];

$meta = [
    'title'          => $post['seo_title'] ?: $post['title'],
    'description'    => $post['seo_description'] ?: $post['excerpt'],
    'canonical'      => '/blog/' . $post['slug'],
    'og_type'        => 'article',
    'og_title'       => $post['title'],
    'og_description' => $post['seo_description'] ?: $post['excerpt'],
    'og_image'       => $og_image,
    'ld_json'        => json_encode([
        '@context'         => 'https://schema.org',
        '@type'            => 'Article',
        'headline'         => $post['title'],
        'description'      => $post['seo_description'] ?: $post['excerpt'],
        'image'            => SITE_URL . $og_image,
        'datePublished'    => $pub_iso,
        'dateModified'     => $pub_iso,
        'url'              => $post_url,
        'mainEntityOfPage' => ['@type' => 'WebPage', '@id' => $post_url],
        'author'           => ['@type' => 'Organization', 'name' => SITE_NAME, 'url' => SITE_URL],
        'publisher'        => [
            '@type' => 'Organization',
            'name'  => SITE_NAME,
            'url'   => SITE_URL,
            'logo'  => ['@type' => 'ImageObject', 'url' => SITE_URL . '/assets/favicon.svg'],
        ],
        'keywords'         => implode(', ', $post['tags']),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
];
?>

<!-- ── Post hero ──────────────────────────────────────────────────────────── -->
<div class="relative pt-36 pb-20 md:pt-44 md:pb-28 bg-ink text-white overflow-hidden">
  <?php if ($post['image_url']): ?>
  <!-- Image background with overlay -->
  <div class="absolute inset-0">
    <img src="<?= htmlspecialchars($post['image_url']) ?>"
         alt="<?= htmlspecialchars($post['title']) ?>"
         class="w-full h-full object-cover">
    <div class="absolute inset-0" style="background:linear-gradient(to bottom, rgba(0,0,0,.72) 0%, rgba(0,0,0,.58) 60%, rgba(0,0,0,.8) 100%)"></div>
  </div>
  <?php else: ?>
  <!-- Clean gradient — no stripes -->
  <div class="absolute -top-40 left-1/4 h-96 w-96 rounded-full blur-3xl pointer-events-none" style="background:rgba(251,191,36,.08)"></div>
  <div class="absolute bottom-0 right-1/4 h-64 w-64 rounded-full blur-3xl pointer-events-none" style="background:rgba(251,191,36,.06)"></div>
  <?php endif; ?>

  <div class="relative mx-auto max-w-3xl px-4 text-center">
    <!-- Tag pill -->
    <span class="inline-block text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-5"
          style="background:rgba(251,191,36,.15);color:#FBBF24;border:1px solid rgba(251,191,36,.3)">
      <?= htmlspecialchars($tag) ?>
    </span>

    <!-- Title -->
    <h1 class="text-3xl sm:text-4xl md:text-5xl font-display font-bold leading-tight">
      <?= htmlspecialchars($post['title']) ?>
    </h1>

    <!-- Meta row -->
    <div class="flex items-center justify-center flex-wrap gap-x-5 gap-y-2 mt-6 text-sm" style="color:rgba(255,255,255,.6)">
      <?php if ($pub_date): ?>
      <span><?= htmlspecialchars($pub_date) ?></span>
      <?php endif; ?>
      <?php if ($post['read_time']): ?>
      <span class="flex items-center gap-1.5">
        <?= icon('clock', 'size-3.5') ?>
        <?= htmlspecialchars($post['read_time']) ?>
      </span>
      <?php endif; ?>
      <span class="flex items-center gap-1.5">
        <?= icon('eye', 'size-3.5') ?>
        <?= number_format($post['views']) ?> reads
      </span>
    </div>
  </div>
</div>

<!-- ── Article body ───────────────────────────────────────────────────────── -->
<article class="py-14 md:py-20 bg-background">
  <div class="mx-auto px-4" style="max-width:700px">

    <!-- Tags row -->
    <?php if (!empty($post['tags'])): ?>
    <div class="flex flex-wrap gap-2 mb-10">
      <?php foreach ($post['tags'] as $t): ?>
      <span class="inline-block text-xs font-semibold px-3 py-1 rounded-full"
            style="background:rgba(251,191,36,.1);color:#B45309">
        <?= htmlspecialchars($t) ?>
      </span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Excerpt lead -->
    <?php if ($post['excerpt']): ?>
    <p class="text-lg leading-relaxed font-medium text-muted-foreground mb-10 pb-10 border-b border-border">
      <?= htmlspecialchars($post['excerpt']) ?>
    </p>
    <?php endif; ?>

    <!-- Body -->
    <?php if ($post['content']): ?>
    <div class="prose-content" style="font-size:1.0625rem;line-height:1.8;color:var(--color-foreground,#18181b)">
      <?= $post['content'] ?>
    </div>
    <?php else: ?>
    <div class="py-16 text-center" style="color:#9ca3af">
      <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin:0 auto 12px;opacity:.4"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
      <p style="font-style:italic">Full article coming soon.</p>
    </div>
    <?php endif; ?>

    <!-- Back link -->
    <div class="mt-14 pt-8 border-t border-border flex items-center justify-between flex-wrap gap-4">
      <a href="/blog" class="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-ink transition-colors">
        <?= icon('arrow-left', 'size-4') ?>
        All articles
      </a>
      <span class="text-xs text-muted-foreground"><?= number_format($post['views']) ?> reads</span>
    </div>

  </div>
</article>

<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
