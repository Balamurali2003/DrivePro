<?php
$meta = [
    'title'       => 'Book Free Demo Class — Sri Munis Kanna Driving School',
    'description' => 'Book a free demo driving class at Tirunelveli Junction. Meet your trainer, see the car, decide with confidence.',
    'canonical'   => '/book-demo',
];
$eyebrow  = 'Book demo';
$title    = 'Try a free demo class first.';
$subtitle = 'No commitment. Just turn up, sit in the car, and see if we\'re the right fit for you.';

$courses_list = ['Beginner Course', 'Ladies Special', 'Advanced Driving', 'Refresher Course', 'License Assistance'];
$perks = [
    '100% free, no obligation',
    'Meet your trainer & see the car',
    'Quick assessment of your level',
    'Personalized course recommendation',
];
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>

<section class="py-20 md:py-28 bg-background">
  <div class="mx-auto max-w-6xl px-4 grid gap-8 lg:grid-cols-5">

    <!-- Form -->
    <div class="lg:col-span-3 rounded-3xl bg-card border border-border shadow-glow p-8 md:p-10 reveal">
      <div class="flex items-center gap-2 text-yellow-deep">
        <?= icon('sparkles', 'size-4') ?>
        <span class="text-xs font-semibold uppercase tracking-[0.2em]">Free demo class</span>
      </div>
      <h2 class="mt-3 text-3xl md:text-4xl font-display font-bold text-ink">Tell us a little about you</h2>

      <div id="demo-success" style="display:none" class="mt-6 rounded-2xl bg-green-50 border border-green-200 px-5 py-4 text-green-800 text-sm font-medium text-center">
        Booking received! We'll confirm your demo class shortly.
      </div>

      <form id="demo-form" class="mt-8 space-y-5" novalidate>
        <div class="grid sm:grid-cols-2 gap-5">
          <div>
            <label for="demo-name" class="block text-sm font-medium text-ink mb-1.5">Full name</label>
            <input id="demo-name" name="name" type="text" required
                   class="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div>
            <label for="demo-phone" class="block text-sm font-medium text-ink mb-1.5">Phone / WhatsApp</label>
            <input id="demo-phone" name="phone" type="tel" required
                   class="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
        </div>

        <div>
          <label for="demo-course" class="block text-sm font-medium text-ink mb-1.5">Course interested in</label>
          <select id="demo-course" name="course" required
                  class="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring">
            <option value="" disabled selected>Select a course</option>
            <?php foreach ($courses_list as $c): ?>
              <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label for="demo-date" class="block text-sm font-medium text-ink mb-1.5">Preferred demo date</label>
          <input id="demo-date" name="date" type="date" required
                 class="w-full h-12 rounded-xl border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>

        <div>
          <label for="demo-notes" class="block text-sm font-medium text-ink mb-1.5">Anything we should know? (optional)</label>
          <textarea id="demo-notes" name="notes" rows="3" placeholder="e.g. complete beginner, prefer morning slot…"
                    class="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"></textarea>
        </div>

        <button type="submit" id="demo-submit"
                class="w-full inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-base font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity shadow-glow">
          <?= icon('calendar', 'size-4') ?> Confirm Free Demo
        </button>
      </form>
    </div>

    <!-- Sidebar -->
    <div class="lg:col-span-2 space-y-6">
      <div class="rounded-3xl bg-ink text-white p-8 shadow-glow reveal">
        <h3 class="font-display font-bold text-2xl">What you get</h3>
        <ul class="mt-5 space-y-3">
          <?php foreach ($perks as $p): ?>
            <li class="flex gap-3 text-white/85">
              <?= icon('check-circle', 'size-5 text-yellow shrink-0 mt-0.5') ?>
              <?= htmlspecialchars($p) ?>
            </li>
          <?php endforeach; ?>
        </ul>
        <div class="mt-8 pt-6 border-t border-white/10">
          <p class="text-sm text-white/60">Prefer to talk first?</p>
          <a href="tel:<?= SITE_PHONE_TEL ?>" class="mt-2 flex items-center gap-2 font-display font-semibold text-yellow text-lg">
            <?= icon('phone', 'size-4') ?> <?= SITE_PHONE ?>
          </a>
          <a href="tel:<?= SITE_PHONE2_TEL ?>" class="mt-1 flex items-center gap-2 font-display font-semibold text-yellow/80 text-base">
            <?= icon('phone', 'size-4') ?> <?= SITE_PHONE2 ?>
          </a>
        </div>
      </div>

      <div class="rounded-3xl bg-gradient-yellow p-8 text-ink shadow-glow reveal">
        <?= icon('message-circle', 'size-8') ?>
        <h3 class="mt-3 font-display font-bold text-2xl">Or just WhatsApp us</h3>
        <p class="mt-2 text-sm text-ink/80">Fastest way to schedule. We'll reply within minutes.</p>
        <a href="https://wa.me/<?= SITE_WHATSAPP ?>" target="_blank" rel="noreferrer" class="block mt-5">
          <button class="w-full inline-flex items-center justify-center rounded-full px-4 py-3 text-sm font-semibold bg-ink text-white hover:opacity-90 transition-opacity">
            Open WhatsApp
          </button>
        </a>
      </div>
    </div>

  </div>
</section>

<script>
document.getElementById('demo-form').addEventListener('submit', function(e) {
  e.preventDefault();
  var name   = this.querySelector('[name="name"]').value.trim();
  var phone  = this.querySelector('[name="phone"]').value.trim();
  var course = this.querySelector('[name="course"]').value;
  var date   = this.querySelector('[name="date"]').value;
  var notes  = this.querySelector('[name="notes"]').value.trim();

  if (!name || !phone || !course || !date) {
    alert('Please fill all required fields.');
    return;
  }

  var btn = document.getElementById('demo-submit');
  btn.disabled = true;
  btn.textContent = 'Booking…';

  var fd = new FormData();
  fd.append('name',           name);
  fd.append('phone',          phone);
  fd.append('course',         course);
  fd.append('preferred_date', date);
  fd.append('message',        notes);
  fd.append('source',         'book-demo');

  fetch('/enquiry', { method: 'POST', body: fd })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      document.getElementById('demo-success').style.display = 'block';
      document.getElementById('demo-form').reset();
      btn.disabled = false;
      btn.innerHTML = '<?= addslashes(icon('calendar', 'size-4')) ?> Confirm Free Demo';
      if (data.wa_url) {
        window.open(data.wa_url, '_blank');
      }
    })
    .catch(function() {
      btn.disabled = false;
      btn.innerHTML = '<?= addslashes(icon('calendar', 'size-4')) ?> Confirm Free Demo';
      alert('Something went wrong. Please call us directly.');
    });
});
</script>
