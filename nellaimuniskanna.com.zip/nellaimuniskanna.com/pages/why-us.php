<?php
$meta = [
    'title'          => 'Why Choose Us — Sri Munis Kanna Driving School',
    'description'    => 'Patient trainers, real road practice, ladies special coaching, flexible timings and complete license assistance — see why Tirunelveli trusts us.',
    'og_title'       => 'Why Choose Us — Sri Munis Kanna',
    'og_description' => "Six reasons learners choose Tirunelveli's premium driving academy.",
    'canonical'      => '/why-us',
];
$eyebrow  = 'Why choose us';
$title    = 'Six reasons families trust us with first-time drivers.';
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>
<?php include __DIR__ . '/../includes/sections/trust-indicators.php'; ?>
<?php include __DIR__ . '/../includes/sections/women-program.php'; ?>
<?php include __DIR__ . '/../includes/sections/testimonials.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
