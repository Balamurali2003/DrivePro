<?php
$meta = [
    'title'       => 'Page Not Found — Sri Munis Kanna Driving School',
    'description' => 'The page you are looking for does not exist.',
];
?>
<section class="min-h-[70vh] flex items-center justify-center bg-background">
  <div class="text-center px-4">
    <div class="text-8xl font-display font-bold text-gradient-yellow">404</div>
    <h1 class="mt-4 text-3xl font-display font-bold text-ink">Page not found</h1>
    <p class="mt-3 text-muted-foreground">The page you are looking for doesn't exist.</p>
    <a href="/" class="mt-8 inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold bg-gradient-yellow text-ink hover:opacity-90 transition-opacity">
      Go home
    </a>
  </div>
</section>
