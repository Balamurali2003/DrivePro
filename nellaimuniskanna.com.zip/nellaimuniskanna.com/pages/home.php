<?php
$meta = [
    'title'           => 'Sri Munis Kanna Driving School — Best Driving School in Tirunelveli',
    'description'     => 'Premium driving school at Tirunelveli Junction. 22 practical classes, ladies special coaching, real-road training & complete license assistance.',
    'og_title'        => 'Sri Munis Kanna Driving School — Tirunelveli',
    'og_description'  => 'Learn driving with confidence & safety. Real-road training, license assistance, ladies special coaching.',
    'canonical'       => '/',
    'ld_json'         => json_encode([
        '@context'    => 'https://schema.org',
        '@type'       => 'LocalBusiness',
        'name'        => SITE_NAME,
        'image'       => '/assets/favicon.svg',
        'telephone'   => SITE_PHONE . ', ' . SITE_PHONE2,
        'address'     => [
            '@type'          => 'PostalAddress',
            'streetAddress'  => 'Tirunelveli Junction',
            'addressLocality' => 'Tirunelveli',
            'addressRegion'  => 'Tamil Nadu',
            'postalCode'     => '627001',
            'addressCountry' => 'IN',
        ],
        'priceRange'    => '₹₹',
        'openingHours'  => 'Mo-Sa 06:00-20:00, Su 07:00-12:00',
        'founder'       => ['@type' => 'Person', 'name' => SITE_OWNER],
    ]),
];
?>
<?php include __DIR__ . '/../includes/sections/hero.php'; ?>
<?php include __DIR__ . '/../includes/sections/trust-indicators.php'; ?>
<?php include __DIR__ . '/../includes/sections/about.php'; ?>
<?php include __DIR__ . '/../includes/sections/courses-section.php'; ?>
<?php include __DIR__ . '/../includes/sections/owner.php'; ?>
<?php include __DIR__ . '/../includes/sections/women-program.php'; ?>
<?php include __DIR__ . '/../includes/sections/testimonials.php'; ?>
<?php include __DIR__ . '/../includes/sections/gallery.php'; ?>
<?php include __DIR__ . '/../includes/sections/license-process.php'; ?>
<?php include __DIR__ . '/../includes/sections/faq-section.php'; ?>
<?php include __DIR__ . '/../includes/sections/blog-preview.php'; ?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
