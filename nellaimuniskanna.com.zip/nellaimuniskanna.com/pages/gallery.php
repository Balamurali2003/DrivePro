<?php
$meta = [
    'title'       => 'Gallery — Sri Munis Kanna Driving School',
    'description' => 'Photos of our training cars, learners, and license success moments at our Tirunelveli driving academy.',
    'canonical'   => '/gallery',
];
$eyebrow  = 'Gallery';
$title    = 'Inside the academy.';
$subtitle = 'Training cars, learners, and real-road moments.';
?>
<?php include __DIR__ . '/../includes/sections/page-hero.php'; ?>
<?php
$compact = false;
include __DIR__ . '/../includes/sections/gallery.php';
?>
<?php include __DIR__ . '/../includes/sections/contact-cta.php'; ?>
